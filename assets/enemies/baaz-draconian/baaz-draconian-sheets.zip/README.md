# Baaz Draconian sprite sheets

Transparent PNG sheets use unscaled 256 x 256 frames. Every sheet has four direction rows in this order: south-east, south-west, north-east, north-west. Frames run left to right.

`reference-v2/sheets/layout.json` records the columns, playable frame count per direction, suggested frame duration, looping behavior and origin. Always use the playable count for the selected direction; unused cells at the end of shorter rows are transparent padding.

`facing.png` contains one standing frame per direction. `idle.png` and `walk.png` loop. `attack.png`, `block.png` and `hit.png` play once and return to idle. `death.png` plays once and holds its final stone-statue frame until the game's shared death effect removes the unit.

Individual authored rotations and animation frames are retained under `reference-v2/`. No horizontal mirroring is needed. This asset set is not registered in encounters or the enemy sprite catalog.
