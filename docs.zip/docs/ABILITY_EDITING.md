# Delve Deep: editing character and enemy abilities

The active roster is data/adventurers.js. Stable roster and class IDs preserve saved progression and gear. Active class catalogs are built by replacementAbilities in data/replacementAbilities.js, using the approved standalone records in data/replacementAbilityCatalog.js.

Edit each replacement record's primary and secondary text, fractional potency, unit, power basis and cap. A potency of 1.2 means 120%, not 1.2 HP. Timing in these records is milliseconds; the design workbook uses seconds. Cast range and area dimensions are authored in arena units, with one pace equal to 100 units. Do not replace continuous geometry with tactical cells.

combat/ReplacementAbilitySystem.js selects useful targets and resolves new effect handlers through the shared battle damage/healing methods. combat/ReplacementEffects.js calculates temporary modifiers without changing permanent stats. game/ReplacementAbilityDescriptions.js describes trained effects and costs in character inspection. game/AdventurerAbilities.js controls learned ranks, equipped slots and one-time catalog migration.

Replacement tooltips use three short sections: the main and secondary effects with their own timings, a compact range/area/cooldown/cost line, and essential requirements or tradeoffs. Keep stat/gear-derived amounts concrete, recipient-based amounts clearly tied to that recipient, and percentage-point bonuses distinct from stat percentages. Avoid copying AI triggers or internal stacking rules into the tooltip. Important conditions such as Stealth, learned Siphon, Health-cost thresholds and limited uses remain visible.

New handler state must use plain saved data, combat-clock timestamps and unit IDs. Keep visual objects outside the model, suppress historical drawing during catch-up, and clean up views on expiry or scene shutdown. Persistent zones and decoys are examples. Use the same handler in visible and background combat.

The spell helper and former abilityWorkbook/abilityProgression tables in data/classes.js support legacy encounter behavior only. Editing those values does not change the active replacement catalog. Existing saved encounter definitions remain intact; new profiles and new encounters use replacement IDs.

Enemy definitions and skills remain in data/enemies.js with their percentage potency normalization. scenes/BattleScene.js owns battle state, damage/healing, targeting and orders. combat/BattleUnit.js applies defenses, costs, action readiness and death/revival. Shared supplied ability artwork is registered in data/abilityEffects.js.

Run node tests/replacement-abilities.test.js for replacement mechanics, npm test for the maintained Node suite, and npm run build for production validation. Focused live checks are in tests/visual/replacement-abilities.spec.js. Android packaging remains a separate build/sync step described in BUILD_AND_DEPLOY.md.
