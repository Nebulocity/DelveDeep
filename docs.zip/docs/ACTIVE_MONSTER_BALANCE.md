# Active Pineshire monsters

Updated 2026-10-13.

Fresh non-boss monsters in Slime Cave, Thornbriar Hollow, Dolmark Den, Old Quarry, Sunken Watch and Murmuring Abyss use 1.15 times their existing tuned Health while the battle is visible. Ordinary progression and farm power use the encounter-specific multipliers below, applied to Attack Power, Spell Damage and Spell Healing. Boss-flagged units, including intermediate Abyss guardians, are excluded. Final-boss escorts receive only the shared 1.15 Health / 1.25 power increment on top of their existing boss-wave profile. Armor, accuracy, movement, abilities, warnings, cooldowns, wave composition, rewards and player stats remain unchanged. Reused encounter IDs inherit their template's profile.

| Encounter | Active ordinary power multiplier | Increase over idle power |
| --- | ---: | ---: |
| Slime Cave | 1.75 | 75% |
| Thornbriar Hollow | 2.2 | 120% |
| Dolmark Den | 3 | 200% |
| Old Quarry | 2.3 | 130% |
| Sunken Watch | 1.75 | 75% |
| Murmuring Abyss | 4 | 300% |

These are relative to the previously reduced idle totals, rather than replacing the catalog totals. For example, Quarry's ordinary power becomes 23% of catalog power in active play, Watch 35%, Dolmark 75% and Abyss 40%. The first shared 15%-Health / 25%-power candidate remained safe unattended in the measured earlier Delves. Stronger encounter-specific profiles were needed to create a leadership advantage without weakening party AI.

The active increase is stored separately from the established encounter tuning. Background combat returns to the saved idle baseline before replay timers resolve. Return to visible combat preserves the remaining Health fraction, including a partially fought staged farm wave. Repeated transitions cannot compound the multipliers. New optional per-unit baseline records use the existing version-1 snapshot serializer. Already saved pre-change monsters remain untouched until a fresh spawn replaces them.

Active means visible, focused and caught up, including a battle left open without any taps. There is no inactivity timeout. Hidden tabs, unfocused or minimized browser windows, and backgrounded Android apps use idle stats. Visibility, window focus and Android lifecycle signals are tracked separately, so focus cannot override a hidden tab or backgrounded app. Closed-game time settles through the existing saved timestamp catch-up. Lifecycle changes switch live monster profiles immediately, including while paused, and replay keeps idle totals until catch-up finishes. The offline farm estimator retains its payout and no-new-deaths rules; it still learns its cycle duration from completed visible farm cycles, which can now take longer.

The earlier THORNBRIAR_BALANCE.md, DOLMARK_BALANCE.md and REGIONAL_BALANCE.md reports intentionally target safe unattended ordinary combat. Their ordinary results now describe the retained idle stat profile, rather than establishing active-play safety. Their final boss-unit stats remain unchanged, but stronger visible non-boss escorts can alter whole boss-fight results.

## Simulation protocol

tests/visual/active-monster-simulation.spec.js uses the established actual Phaser harness at 915x412. Six supported seeded parties cover all three tank classes, one/two-healer cohorts and randomized damage members. Each preparation runs seeds 11 and 22, carrying actual resources through every progression wave into the requested farm. Early/mid/cap levels are 1/3/5, 5/7/10, 10/12/15, 15/17/20, 20/23/25 and 25/26/30. Abyss separately covers camps 15 and 33 with its existing prepared gear and fully spent skill-point builds. It checks level-25 entry farming and complete progression with/without commands, recommended level-26 farms at both camps and cap-level farms. Earlier Delves keep the original cheapest compatible Common gear and three starter skills without potions.

Both sides own identical tactics purchased through normal rules. Conservative entry Renown budgets are 1/3/5/7/9/11: one starting RP, one preceding-boss achievement and one five-level character milestone per previous Delve. Active fixtures prioritize Focus!, Encourage!, Brace!, Regen! and Fight On!, skipping unaffordable purchases and obeying the five-slot loadout. This gives Thornbriar Focus/Encourage, Quarry Focus/Encourage/Brace/Fight On, Watch Focus/Encourage/Brace/Regen and Abyss those four plus Fight On. Skill training and gear are funded preparation fixtures; they do not establish acquisition time or an optimal build.

The commanded policy presses useful affordable tactics, focuses damage targets, redirects tanks only toward enemies pursuing a critically hurt non-tank, and gives an idle healer an injured ally priority. It avoids canceling committed ally casts. Slow ordinary casts can receive the current free Interrupt order after a 1.5-second reaction delay, at most once per three seconds. The earlier periodic Move/Hold policy remained a separate preliminary comparison; increasing power under that policy sometimes caused more commanded losses than unattended losses. No new gameplay mechanics, tapping bonuses or AI handicaps were introduced.

The renderer-saving replay mechanism is explicitly held on active stats before timers and updates, and each ordinary unit is checked against its active baseline. Estimated offline rewards are excluded. Run npm run test:visual -- active-monster-simulation.spec.js --workers=1. DELVE_ACTIVE_FARM_MS can extend the default ten-minute farm interval. Raw reports and local delivery adapters remain ignored under output/qa/active-monsters and .tmp.

The maintained check requires viable commanded camp/farm completion and fewer casualties than matched unattended runs. Strong parties can still win unattended; the goal is increased pressure and a measured leadership advantage, rather than a guarantee that every composition loses without input. One-hour endurance repeats a pressured commanded party against the same two seeds, with matched unattended runs. Most selections use the lowest commanded Health in the final short cohort; Quarry retests the party that exposed the rejected 2.5-power profile. These are targeted stress checks, not an exhaustive party/seed sample.

An existing Interrupt tooltip incorrectly described ready ally skills. The actual public command directly cancels an enemy's current action without adventurer selection. The tooltip was corrected to match that existing behavior; requirements and cooldowns were not changed.

## Final actual-combat results

The final short checks contain 360 progression/farm sequences, covering all fourteen adventurers. Matching comparisons below use departure entry levels 1/5/10/15/20 and the recommended Abyss farm level 26. Each earlier row has twelve runs per side; Abyss combines twelve at each camp. Survival means the party remained farming at the end of the requested ten minutes, not that every individual lived.

| Encounter | Unattended farms survived | Commanded farms survived | Unattended deaths | Commanded deaths |
| --- | ---: | ---: | ---: | ---: |
| Slime Cave | 7/12 | 12/12 | 26 | 0 |
| Thornbriar Hollow | 11/12 | 12/12 | 5 | 0 |
| Dolmark Den | 11/12 | 12/12 | 6 | 0 |
| Old Quarry | 4/12 | 12/12 | 40 | 1 |
| Sunken Watch | 10/12 | 12/12 | 10 | 0 |
| Murmuring Abyss | 22/24 | 24/24 | 11 | 0 |

All 84 matched commanded farms survived, versus 65/84 unattended. Matched commanded progression reached all 84 requested camps, versus 78/84 unattended. The extra twenty-four commanded Abyss level-25 entry/progression runs also reached their requested camps, with one casualty across that bridge cohort. That validates access to the early farm without imposing a new level-26 entry lock. Midpoint and cap fixtures remain in the full reports.

All fourteen selected commanded one-hour farm trials survived. They include two runs for each ordinary Delve and four Abyss runs split between its two camps. The Abyss hour cohort had one individual casualty; the other selected commanded hours had none. Unattended hour survival was 2/2 Slime, 2/2 Thornbriar, 0/2 Dolmark, 0/2 Quarry, 2/2 Watch and 2/4 Abyss. One selected unattended Quarry party failed before reaching farm, so these are requested-hour trial counts, rather than a claim of twenty-eight completed farm hours. Commanded farm repeats totaled 1,079 across the fourteen completed hours.

Quarry's rejected 2.5-power profile passed short farming but both selected commanded one-hour trials eventually wiped. Repeating the same party/seeds at 2/2.15/2.3 power showed that 2.3 retained unattended losses while allowing both commanded hours to finish without deaths. The final broad Quarry check was rerun at 2.3. Its narrow hour Health minimum was 5.3%, so it deliberately has less safety margin than the former idle-oriented balance. Slime/Thornbriar/Dolmark/Watch selected commanded hour minima were 22.4%/16.4%/12.0%/52.8%; Abyss's individual casualty makes its overall minimum zero.

These comparisons support a real command advantage. They do not make input universally necessary: strong sampled parties still win automatically, particularly at midpoint/cap levels. The intervention policy reacts deterministically and can use an existing control promptly; physical Pixel 9 play, less precise inputs and every party composition are not established by these runs.

## Validation

The active-stat, pause/idle/return, saved-baseline reload and older-save compatibility checks pass. Optional baseline validation rejects nonfinite, negative or overflowing stat arithmetic without changing version-1 compatibility. Boss stat/preparation, checkpoint, reward and identity checks pass. Production build passes using the existing local preserve-symlinks configuration after the normal build hit the documented main.js realpath EPERM. Full Node validation is 86/89 with the same existing replacement-abilities, selective-travel and shop-services failures.

Final authored reports, paired hour records and the consolidated summary are under ignored output/qa/active-monsters/final. Preliminary shared boosts, rejected policies, candidate sweeps and file-delivery adapters remain ignored in output/qa/active-monsters and .tmp. Finished code needs no generation service or API key.

