# Asset pipeline

Selenne and Malrek use standalone six-sheet sets under their respective
`assets/characters/<id>/sheets/` folders, named `Selenne-<state>.png` and
`Malrek-<state>.png`. Their small JavaScript catalogs read frame counts, timings,
measured boot anchors and display scale from `layout.json`. Four authored facing
rows keep weapons in their original hands. Approved PNG references live alongside
the sheets; private generation records and packing tools remain ignored under
`work/cleric-sprites/`. Offline previews and the combined sheet ZIP are under
`output/qa/cleric-sprites/` and the two character-specific QA folders. No service
access or source-frame download is needed to build or play.

Runedancer's twelve gemstone abilities share six transparent rune atlases in
`assets/effects/runedancer/`: `garnet-rune-sheet.png`, `fluorite-rune-sheet.png`,
`aquamarine-rune-sheet.png`, `ruby-rune-sheet.png`, `sapphire-rune-sheet.png` and
`amethyst-rune-sheet.png`. Matching `*-rune.png` files retain a standalone 112x112 sprite.
The approved rupee-shaped gems use broad facets and bright flowing script.
Each eight-column, eight-row sheet has 64 frames of 112x112 pixels at 30 FPS,
with a gentle hover, faint color-matched halo and stronger central rune pulse.
One seamless loop lasts about 2.13 seconds. Registrations bind saved skill behaviors to gemstones rather
than deriving filenames from display names. Existing fixed positions, impact timing,
saved rune restoration and paused 400 ms fades remain in use. Finished art is
standalone; prompts, packing tools and review output remain ignored in
`work/gemstone-runes/`. The old ability IDs and handlers are intentionally retained
for learned ranks, loadouts and recorded encounters.

The local class-selectable effects gallery is `output/qa/ability-effects/index.html`.
The original `output/qa/everbright-cleric/index.html` link shows the same library.
Both are self-contained offline HTML files with embedded finished PNGs, and can be
opened by double-clicking in an ordinary browser or copied to another computer.
The selector includes all thirteen playable classes, permitted shared abilities,
extra cosmetic phases, real delivery profiles and clearly marked unfinished art.
Search, authored-speed playback, pause, restart and a 400 ms finish fade are available.
`Open Gallery.cmd` opens the neutral page in the default browser. In the original
project folder, `Refresh Gallery.cmd` rebuilds both pages from current registrations
using `work/ability-effects-gallery/build-gallery.mjs` and its editable HTML template.
The snapshot is not automatically updated when another chat adds effects.
Preview files, embedded snapshots, builder and browser checks remain ignored;
no gallery authoring or review code is added to the shipped game.

Barmaid's current twelve abilities use fifteen transparent 96x96 atlases in
`assets/effects/barmaid/`, registered in `data/barmaidAbilityEffects.js` as sixteen
phases. The six-column sheets contain 32 frames at 20 FPS. Pan stun reuses Last
Call's dazed sheet. The kit uses steel, amber drink, green glass, wooden fragments,
a serving-tray guard, bar counter, palm and potion motifs without cosmetic floor
circles. The irregular spill fits its saved ground location and projected radius.
Persistent modifiers, periodic bleeding, zones and reactions own their lifetime;
all sheets and 400 ms fades use paused combat time. Existing source-less stun and
intercept records cannot distinguish the skill after reload, so the pan cue resumes
on its next live hit and interception retains its shared badge until recast.
Current abilities form locally and launch no objects. Exact replacement IDs retain
legacy presentation, including the retired Tray Toss flight. Finished PNGs ship
without generation dependencies. Editable records, native export recovery and
authoring remain ignored under `work/barmaid-vfx/`; the self-contained animated
gallery and phone-size captures remain under `output/qa/barmaid/`. Native frames
were recovered from PixelLab's 1x inspection output when direct downloads were
unavailable, with its reported palette counts verified. Authoring used no
generation credits. Focused playback, lifecycle and Phaser checks passed.


Umbral Mage's twelve current class abilities ship seventeen transparent PixelLab
atlases under `assets/effects/umbral-mage/`, registered in `data/umbralMageEffects.js`.
Each six-column atlas has 32 frames at 20 FPS. Body and field sheets use 96x96
cells, Shadow Bolt flight 64x32, and the two drain connections 160x48. Finished
PNGs are standalone runtime assets. The shared renderer moves the bolt and reveals
the draining connections from their casters, with separate impact and recovery
art. Meditation, its earned spell focus, Shadow Trap, Eclipse Field and Shadow
Image follow existing saved records. Eclipse Field uses branching floor fissures
at its fixed ground point; its cosmetic art replaces the former zone ellipse.
Expired or replaced Umbral decoy sprites leave a paused 400 ms cosmetic fade while
leaving the active decoy list immediately. Artwork uses the same combat-time fade.
Legacy saved Nightbolt and other definitions retain their supplied sheets. Recipes,
PixelLab effect records and export provenance stay ignored under `work/umbral-vfx/`;
the animated gallery, captures and offline Phaser review stay in
`output/qa/umbral-mage/`. PixelLab authoring used no generation credits. Physical
Android readability review remains pending.


Barbarian's twelve current class abilities ship sixteen transparent 96x96 PixelLab
atlases under `assets/effects/barbarian/`, registered in `data/barbarianAbilityEffects.js`.
Each six-column sheet has 32 playable frames at 20 FPS. Heavy cleaves, steel and
crimson swings, tusks, keen eyes, focus brackets, adrenaline bolts, a prepared axe
and rage plumes provide local art without cosmetic ground circles. Potion refill,
taunt and weakening clips are separate from primary ability artwork. Status
art restores through existing modifier/preparation records; Primal Roar's enemy
challenge uses the living forced-target owner's active Primal Roar modifier to
identify the source-less taunt deadline. Playback and 400 ms fades use combat time;
replay/shutdown clear immediately. Current Barbarian skills launch no objects.
Legacy saved ability definitions retain their previous presentation. Recipes,
PixelLab records and exports stay ignored in `work/barbarian-vfx/`; an animated
gallery and phone-size captures live in ignored `output/qa/barbarian/`. Authoring
used PixelLab's free VFX workbench with no generation credits.

Everbright Cleric's current kit uses eighteen finished transparent PNG atlases under
`assets/effects/everbright-cleric/`, plus the accepted Sunlit Ward sphere. The primary
registration is `data/everbrightClericEffects.js`. All new sheets have 32 playable
frames at 20 FPS, with six columns and six rows. Local art uses 96x96 cells; Radiant
Bolt's stationary flight uses 64x32 cells and Judgement Ray's uses 160x48 cells.
Holy Light, Guardian Spirit, Cleansing Fire and Divine Reprisal have synchronized
rear/front sheets to keep bodies readable. Exact replacement IDs preserve older
saved ability artwork. Existing modifier and periodic records restore lasting art;
the shared Ward marker retains its existing restore path. Guided Retribution's
effective healing and Divine Reprisal's confirmed secondary hits use separate
cosmetic phases. The bolt follows a straight path and the ray reveals outward
from its source during the existing windup; both use the shared travel renderer.
Local blessings and summoned flames launch no object. Frames and 400 ms retirement
fades pause with combat; replay and shutdown release artwork immediately.
PixelLab recipes, editable effect IDs, export JSON/GIFs and provenance stay ignored
under `work/everbright-cleric/`; an animated gallery and battlefield captures stay
under `output/qa/everbright-cleric/`. Authoring consumed no generation credits.

Ranger's twelve replacement class abilities ship seventeen transparent PNG atlases
under `assets/effects/ranger/`, registered by `data/rangerAbilityEffects.js`.
Each atlas has six columns and six rows with 32 playable frames at 20 FPS.
Status and impact cells are 96x96; the four dedicated arrow flights are 64x32.
The flight renderer supplies straight trajectories for single shots and three
arced trajectories for Volley, preserving the existing gameplay hit timestamp.
Stationary flight sheets rotate with their trajectory and remain separate from
resolved impacts. Hunter's Trap uses fixed steel jaws instead of a cosmetic ground
circle; its triggered poison follows the victim's periodic damage record. Support
motifs use leaves, sight glyphs, a stitched herbal bandage, antlers, scout chevrons
and a prepared bow. Compact glyphs fit their measured opaque bounds.
All art fades over 400 combat milliseconds, freezes on Pause and releases immediately
on replay/shutdown. Saved gameplay statuses restore the current loops without new
save fields. Pinning Arrow's source-less root deadline supports live visuals but
cannot identify its originating ability after reload. Legacy definitions keep
their old supplied effects. Editable recipes, PixelLab records, export JSON/GIFs
and review captures remain ignored under `work/ranger-vfx/` and `output/qa/ranger/`.
The VFX workbench used no generation credits. Focused lifecycle and phone-size
Phaser checks passed; physical Android review remains pending.

Verdant Cleric's twelve abilities use finished transparent PNG atlases under
`assets/effects/verdant-cleric/`, registered in `data/verdantClericEffects.js`.
Each six-column atlas has 32 playable 96x96 cells at 20 FPS. The revised artwork
removes cosmetic ground circles from Ironwood Armor, Spring Canopy, Regrowth,
Nature's Touch, Lifequake, Leeching Vines, Brambles and Entangling Roots. A compact
bark cuirass, leafy arch, healing leaves and plus symbols, angled sunlight, tangled
brown foot roots and woody thorn branches distinguish the abilities. Nature's
Embrace has a thicker isometric band with twenty leaves, centered at 58% of the
visible body's height; rear and front sheets let the character hide the far side.
Wrath reuses the accepted separate bolt sheet with a green
tint and the shared combat-time travel system; its new nature burst plays on contact.
Brambles reads its saved owner zone while anchoring the artwork at the zone point.
Brambles and Lifequake project their ground artwork to the existing 200-unit radius.
Lifequake spreads dark branching cracks for 1.6 combat seconds, holds that last
frame, then starts separate rear/front eruption sheets for another 1.6 seconds.
Upright light uses uniform scaling while cracks retain their floor projection.
Nature's Touch keeps a translucent sunlight layer behind its healing leaves and
symbols. Roots uses complementary crops above and below its foot anchor.
All effects use 400 ms combat-time fades; replaced ground fields fade at their old
locations. Armor, periodic healing, shield and reflection effects follow their existing
records. Roots uses the shared `rootedUntil` deadline for live playback, but cannot
identify the source of a restored root and therefore waits for the next cast after
reload. Historical replay and shutdown clear artwork immediately. Only finished
PNGs and JavaScript ship; editable records, exports and animated previews stay
ignored under `work/verdant-cleric/` and `output/qa/verdant-cleric/`. PixelLab's free
VFX workbench authored this set without generation credits.

Gladiator Protect ships four finished PixelLab PNG atlases in
`assets/effects/gladiator-protect/`, registered by
`data/gladiatorProtectEffects.js`. Iron Guard uses a layered steel shield sphere under `assets/effects/shield-spheres/iron/`, Defiant Roar
marks taunted enemies in crimson, Shield Bash has a gold metallic hit burst, and
Battle Formation places gold runes at affected allies' feet. Each atlas contains 32
frames at 20 FPS. Status artwork follows existing saved protection or taunt records;
the impacts and status marks fade over 400 combat milliseconds. None of these skills
launches an object. Editable PixelLab effects and export previews remain local under
ignored `work/` paths.

Dawnwarden Restore ships four finished PNG atlases in
`assets/effects/dawnwarden-restore/`, registered by `data/dawnwardenRestoreEffects.js`.
Each has 32 frames at 20 FPS and a 400 ms combat-time finish fade. Renewing Light
uses a translucent gold pillar; Devotion a blue Mana sigil; Cleansing Radiance a
pale sweep with healing crosses; Dawn's Guidance rings formed at its resolved ally.
These immediate local effects reuse resolved ability callbacks and require no new
saved fields or projectile. Editable PixelLab records and export provenance remain
local under ignored `work/dawnwarden-restore/`.

Selective ranged delivery is authored in `data/rangedTravelEffects.js`, independently
of numeric cast range. `combat/TravelingEffects.js` plays straight arrows/bolts/lances,
arced thrown objects, guided missiles and extending beams/tethers/whips during the
existing cast. Shared arrow, bolt and lance sheets are under `assets/effects/ranged-delivery/`
with 32 frames at 24 FPS; stones reuse the accepted Quarry projectile. Direct marks,
curses, cleanses, auras, summoned sky strikes and ground eruptions stay local. Live
targets are tracked, captured ground-warning destinations remain fixed, and interrupted
flights fade at their stopped position. Frames, travel and 400 ms fades use combat time.
Saved active flights rebuild from existing action/event records without new save fields.

Oathwarden's four replacement Assault abilities use finished sheets in
\`assets/effects/oathwarden-assault/\`, authored at 32 frames and 20 FPS. Righteous
Blow and Piercing Vow play separate direct hit art. Vow of Condemnation and Vow of
Retribution follow their targets while the existing harmful modifier or retaliation
record remains active, then fade over 400 combat milliseconds. All four skills have
adjacent reach and launch no object, so their visual starts at the resolved target.
The status art restores after a saved battle without adding save fields.

Generic Prepare effects ship in `assets/effects/generic-prepare/`: Arcane Focus,
Quick Casting and Ready Weapon use 48 by 48 pixel cells, and Combat Footwork uses
64 by 32 pixel cells. Each six-column atlas has 32 playable frames at 24 FPS.
`combat/PrepareAbilityEffects.js` reads existing preparation and movement records,
follows visible caster bounds, restores after reload and fades for 400 combat
milliseconds on consumption, expiry, removal, death or battle end. Footwork stays
until its movement bonus ends, even after its next-windup preparation is consumed.
Pause freezes playback and fading; historical replay and shutdown clean up at once.
Only finished PNGs ship. Export manifests, editable effect records and GIF previews
stay local under ignored `work/generic-prepare/` and `output/qa/generic-prepare/`.

Oathwarden Prepare effects ship in `assets/effects/oathwarden-prepare/`. Oath of the
Supplicant plays a one-shot gold ground sigil after restoring potion charges. Steadfast
Focus uses a silver-blue rune seal while its Protect cooldown modifier is active. Vow of
Readiness places a gold ring and rising motes around each ally while its Dodge modifier
is active, even after its one-use windup benefit is consumed. Vow of Retaliation
uses a red parry rim while its counterattack record is active. Each PixelLab atlas has 32
frames at 20 FPS. Origins keep the two ground effects at the party member's feet. Status
drawings restore from existing saved records and fade for 400 combat milliseconds on
expiry or removal. The charge-refill drawing plays once, then fades over 400 combat
milliseconds. No Oathwarden Prepare skill launches an object. Art pauses with combat;
historical replay and shutdown clear drawings immediately. Authoring and export details
remain local under ignored `work/oathwarden-prepare/`.

Finished runtime art lives under `assets/`. Integrated character sheets are in
`assets/characters/<id>/sheets/`; enemies use `<encounter>/<id>/sheets/`.
Each set retains its accepted PNGs and `layout.json`. Runtime catalogs in
`data/characterSprites.js`, `data/enemySprites.js`, `data/slimeSprites.js`,
`data/voidSprites.js`, `data/sunkenWatchSprites.js`, and `data/quarrySprites.js` contain
stable texture keys, frame counts, timings, scales, facings, and foot origins.
Character IDs remain aligned with `data/adventurers.js`. Texture keys can retain
`reference-v2` for compatibility even though filesystem paths no longer use that name.

Aldren's accepted original knight artwork uses six `Aldren-<state>.png` sheets in
`assets/characters/aldren/sheets/`, with `data/aldrenSprites.js` as its authoritative
runtime definition. Preserve its stable roster ID and `aldren-reference-v2-*` texture
keys for existing saves. The native 128-pixel art is enlarged exactly 2x with nearest
sampling into 256-pixel cells so existing portrait sizes remain readable; no colors or
animation drawings are repainted. Four measured boot origins and a 0.8 battlefield
scale align the new artwork with the party. All six clips retain their complete
approved frame counts. The retired sheets and temporary walking experiment are archived
under ignored `project-backup/Aldren-replacement/`; no old artwork remains in the game.
Authoring, original frames, standalone previews and integration reviews remain under
ignored `work/Aldren/` and `output/Aldren/`. Do not regenerate this dedicated definition with
the older monolithic catalog builder, which assumes the retired filenames and anchors.

Legacy Ranger Volley uses seven supplied arrow-rain sheets in `assets/effects/volley/`.
`data/abilityEffects.js` contains playable counts, origin offsets and 20 FPS timing;
`combat/AbilityEffect.js` manages layered, pause-aware playback and cleanup. The supplied
arrow frames already bake in their movement, so exported movement offsets are not applied
again. Runtime needs only these finished sheets and code, with no service connection.

Thirteen more class abilities use 23 supplied sheets in `assets/effects/`: Sanctity Nova,
Sunbrand Strike, Nightbolt, Gloomburst, Eclipse Field, Hunter's Mark, Exploding Arrow,
Surprise Attack, Smoke Bomb, Back Alley Cut, Sunlit Ward, Morning Chorus and Everbright
Pulse. `data/suppliedAbilityEffects.js` and `data/abilityEffects.js` hold
the finished packs' timing, offsets, playable counts and layer order;
`data/abilityEffects.js` binds them to existing class/skill names and preloads them.
Split parts replace combined sheets rather than drawing both. Pixel filtering and
whole-number base scaling preserve the exported art. The requested Nova width stretch
and fitted Ward bubble allow nonuniform scaling. Import manifests and README files
remain local under ignored `work/ability-effects/imports/`.

Nightbolt and Exploding Arrow fly toward the current target during the existing cast
windup. Arrow frames span that flight; the orb loops. Exploding Arrow's separate
explosion starts only after confirmed contact, including a blocked/absorbed hit but
excluding accuracy misses, dodges, immunity and canceled casts. Damage timing, potency,
single-target behavior and saved ability IDs are unchanged. Hunter's Mark displays only
the floating triangle, cropping the lower glowing ring from each sheet cell while
preserving its size and placement. The triangle loops and
follows its target until death, replacing old art when reapplied. Its existing ten-second
damage bonus still expires normally. The optional saved `huntersMarkVisual` status flag
recreates the marker after reload or idle catch-up; death clears it.
Eclipse Field plays one visual cycle because its current workbook duration is zero;
it now uses `assets/effects/ground-sigil/whole.png`. The old two-part Eclipse artwork
is preserved locally under ignored `work/ability-effects/retired/eclipse-field/`.
The supplied loop flag does not create ongoing damage. Caster-centered abilities
anchor on the caster; target-centered abilities anchor on the resolved target.
All effects use paused combat time, skip historical replay and clean up on shutdown.
Gloomburst, Eclipse Field and Smoke Bomb remain fixed at their resolved ground origins.
Their visual rectangles include resolved recipients and draw above every affected
sprite, overriding supplied behind layers. Sanctity Nova is 2.5 times as wide and
follows its caster. Sunlit Ward uses separate rear/front sheets under `assets/effects/shield-spheres/sunlit/`,
with 32 frames at 20 FPS. It follows its recipient's stable idle silhouette and keeps
a circular shell large enough to contain the body's diagonal. Its optional
saved `sunlitWardVisualUntil` timestamp restores the bubble only while shield HP remains
and the Ward duration has not expired. Full absorption, expiry, death and battle end start a 400 ms combat-time fade.
Morning Chorus uses separate yellow column and blue musical-note layers. Everbright
Pulse uses its blue column sheet. Each immediate area heal plays one visual instance
on every resolved living ally inside the existing healing circle. Columns follow their
individual recipients and use a 200-unit visual footprint rather than the area radius.
Both packs loop at full opacity for 1.5 combat seconds, then fade out over 0.4 seconds.

Generic magical Protect artwork lives in `assets/effects/magical-{hex,nullify,spellbind,spellward}/whole.png`.
Each transparent 96 x 96 sheet has 32 playable frames at 20 FPS. Hex uses violet
orbiting runes; Spellbind uses blue binding arcs; Nullify draws an inward silver-violet
sweep; Spellward draws a rising mint cleanse ring. Open centers preserve creature
readability. `data/magicalProtectionEffects.js` binds stable ability IDs across eligible
caster classes. Hex and Spellbind follow existing saved status records, refresh without
duplicate artwork, restore after catch-up, and fade for 400 combat milliseconds after
expiry, cleansing or death. Nullify and Spellward play once for 1,600 ms, fading through
their final 400 ms. Pause freezes frames and opacity; shutdown and historical replay
clean up immediately. This remains the project rule for future cosmetic effects.

Spellward shares its finished sheet between two complementary crops. The crop line
follows the ring center from row 72 to row 27, putting the upper far half behind the
recipient and the lower near half in front. Both halves share frames, position and
opacity, so the rising ring wraps around the body rather than crossing through it.
PixelLab authoring records and preview GIFs remain ignored under `work/magical-protection/`;
browser captures and review builds remain ignored under `output/qa/magical-protection/`.
Pause freezes both frames and opacity, and final cleanup destroys every layer.
The generic green traveling dot is replaced, while heal text/flash and the amount of
health restored remain unchanged. The packs' loop flags do not create additional heals.
Browser captures and the offline QA build are under ignored
`output/qa/supplied-effects/`.

The Murmuring Abyss uses Void Crawler, Void Stalker, Void Keeper, Abyssal Sovereign and
Void Wisp sheets under `assets/enemies/murmuring-abyss/<id>/sheets/`. Four authored
diagonal rows use transparent 256-pixel cells, with playable counts, timings and anchors
in `layout.json`. Alongside the six shared combat states, the Stalker has a leap and
the floating casters have separate ranged/area clips. `data/voidSprites.js` preserves
legacy void sprite IDs and queues shared textures once. Cast playback follows the
actual windup; projectile/beam effects use combat time and clear during catch-up or
shutdown. The combined ZIP includes a portable interactive preview, and individual
GIFs are under ignored `output/qa/void-baddies/`. Source boards, prompts, service records
and authoring tools remain local under ignored `work/void-baddies/`.

Abyssal Sovereign uses its approved revised halo, crescent-blade and curled-tentacle
design. Nine sheets retain the existing four rows, state names and 240 playable cells.
Its complete lower silhouette replaces the detached bottom ornaments. Anchors are
measured from the revised facings; the existing texture keys and runtime scale remain
compatible. The portable roster ZIP and previews include this replacement.

Sunken Watch's four supplied monsters use eight standalone transparent sheets each:
facing, idle, walk, attack, cast, block, hit and death. Four independently authored
diagonal rows use 256-pixel cells with native 128-pixel PixelLab artwork padded without
resizing. Layouts provide counts, timing, foot origins and top bounds. The 112 source
clips and generation records remain under ignored `output/sunken-watch/`; runtime only
needs the finished sheets and JavaScript catalog. The offline animation preview,
animated lineup, contact sheets and standalone ZIP are under ignored
`output/qa/sunken-watch/`.

Old Quarry's standalone package is under `assets/enemies/old-quarry/`. Quarry Worm,
Quarry Behemoth, Quarry Reaver and Depths Sovereign each have eight sheets with four
authored diagonal rows in 256-pixel cells. Six shared effect sheets supply rock and
crystal projectiles/impacts, ground spikes and stone eruption. All 38 sheets contain
846 playable cells; their layouts include counts, timing, loop settings and anchors.
`data/quarrySprites.js` provides sprite/effect metadata and the BattleScene preloader.
`data/levels/OldQuarry.js` owns the underground quarry scenery and floor; its six waves use
all four Quarry monsters. The saved `march-west-delves` map ID selects this roster
even when an older snapshot names Dolmark. Basic stats are provisional inherited
profiles; authored special abilities and effect playback remain pending. The sheet ZIP, animated
comparison, per-enemy GIFs and interactive review are under ignored
`output/qa/old-quarry/`. Source material and generation records remain under ignored
`work/old-quarry/`; they are not build or runtime dependencies.

Completed integrated source frames, rotations, references, older Elyra pipelines,
and the prior Dolmark image are archived under ignored
`project-backup/cleanup-2026-10-08/original/`, mirroring their original repository paths.
`movement-manifest.json` records every original/destination path, byte count and SHA-256.
Runtime sheet moves are also checksummed. Preserve this archive separately for art edits.
Do not put prompts, service jobs, private tooling, or provenance back into Git.

Local packers use `scripts/sprite_source_paths.py` to read archived sources and write
runtime sheets separately. `scripts/pack-sprite-sheets.py <id>` packs character frames;
`scripts/build-sprite-catalog.mjs` reads finished layouts to rebuild the character catalog.
The enemy packers follow the same source/output split. If the archive moves outside the
checkout, set `DELVE_SPRITE_SOURCE_ROOT` to its `original/` directory. Keep the archived
source tree and local scripts together. The targeted cleanup script for Yasmin,
Nadira, Zahra, and Hedge Mage now reads this preserved source tree.

Baaz Draconian uses its finished sheets under
`assets/enemies/baaz-draconian/reference-v2/sheets/`, registered by `data/baazSprites.js`
and the shared enemy catalog. Its seven-cell south-east attack excludes sheet padding.
Its stone death uses the shared monster finish. Encounter placement remains pending.
Unfinished or pending art is separate from completed runtime sets. Creature samples,
palette variants and Xak Tsaroth concepts remain future content. Do not move unfinished
outputs or the active root `SPRITE_CONTINUATION.md` handoff on the assumption they are
unused. Use supplied references and PixelLab when making new sprites.

Monster deaths play their authored clip, flicker, fade, and finish with a small pop.
Keep that finish in shared presentation. Slime idle motion, attacks and hit reactions
remain active. Validate integration with focused maintained sprite checks,
`npm run build`, and targeted browser review; do not run the full suite by default.
packing tools and source frames must not be required for these runtime checks.

The seven authored environments are defined in `data/levels/`. Slime Cave uses
`slime-cave-pixel/cave.png`, Thornbriar uses `thornbriar-hollow-pixel/camp.png`, Dolmark
uses `dolmark-den-pixel/den-v2.png`, Murmuring Abyss uses its portal art, and Verdant Tear
uses its knoll art. Old Quarry uses `old-quarry-pixel/chamber.png` with masked foreground rubble and procedural lantern/crystal light layers. Sunken Watch uses sunken-watch-pixel/chamber.png with masked foreground masonry and procedural lantern/water layers. Each level defines its own floor boundary, foreground masks, and
ambient effect coordinates. Foreground scenery occludes sprites without blocking the
continuous lower floor. Retained Blender source is local and independent of these
current pixel-art exports; see [Blender pipeline](BLENDER_PIPELINE.md).

Town concepts under `assets/screens/town-concepts/` are loaded by BootScene for town
backgrounds and held details. Delve preparation previews use authored battlefield art,
not the retired concept crops. Retired map-builder/tileset material and earlier world
map implementations remain in ignored `project-backup/`, with the original movement
manifest. They are not runtime dependencies.

Selected regional art remains under `assets/world-map/illustrated-regions-v1/`.
Pineshire v4 is integrated through `data/illustratedWorldMap.js` and
`scenes/ScrollingWorldMap.js`. Regions 2–9 remain selected future backgrounds. Their
manifest carries proposed authoring anchors; current runtime roads and gates are defined
in JavaScript. Generated review reports belong under ignored `output/qa/`, separate
from source archives.

The Slime Cave's four monster abilities use PixelLab sheets in
`assets/effects/monster-slime-cave/`: Slime Slam, Crushing Slime Slam, Toxic Glob and
Consume. Each atlas has 32 frames at 18 FPS. `data/slimeAbilityEffects.js` registers
the cell sizes and loads the sheets only for this encounter; `combat/SlimeAbilityEffects.js`
plays impacts and fades both effects and retired warning rings over 400 combat
milliseconds. Toxic Glob uses separate 32-frame projectile and splash sheets. Elder
Slime's glob launches from its body, arcs toward its moving recipient and splashes at
the existing hit time. The Sovereign's lob lands at its fixed ground-warning center.
Canceled lobs fade in place. Saved in-flight casts restore from existing actions and
events without new save fields. Pause stops their clocks. Shutdown and historical
replay clean them up immediately. PixelLab's editable recipes and export metadata
stay ignored under `work/slime-cave-vfx/`; runtime needs only five PNG sheets and game code.

Gladiator's four Assault abilities use PixelLab atlases in
`assets/effects/gladiator-assault/`. Offensive Drill, Brutal Thrust and Punishing
Blow each use distinct 32-frame melee impacts; these adjacent attacks launch no
objects. Relentless Assault uses a looping, subdued attack-up marker behind the
Gladiator while its saved secondary speed modifier remains active. The sheets run at
16 FPS. Brief impacts fade during their last 400 combat milliseconds, and the
persistent buff fades for 400 combat milliseconds after expiry. All four effects
follow visible recipients; pause freezes playback and fading, and scene shutdown or
historical replay clears the art immediately. Existing ability IDs, gameplay timing
and saved status records are unchanged.

Shield sphere variants use transparent rear film and front curved reflections/glints.
Vigilance uses the gold variant, Iron Guard steel, Combat Readiness bronze and Sunlit
Ward warm gold with cyan reflections. Both layers share frames, centers and uniform
scale; the body hides the rear film. Hold The Line and Interpose badges sit inside
the recipient silhouette to avoid visually assigning them to a nearby character.
PixelLab authoring and the review inventory stay ignored under `work/vfx-refresh/`;
only finished PNG sheets and JavaScript are shipped.

Thornbriar enemy VFX ship eight standalone PNG atlases under
`assets/effects/monster-thornbriar/`. Each has 32 playable frames at 20 FPS.
Six impacts register through `data/thornbriarAbilityEffects.js` and load only
for Thornbriar encounters. Two flights register through the shared ranged delivery
catalog: the Lasher ordinary attack and Whip Lash grow textured wood/thorns/leaves,
and Briar Bolt launches a elongated bramble-and-thorn ball. Native colors preserve the bark.
Direct impacts follow their visible recipients; Bramble Shroud uses a foot anchor.
Captured warning centers remain fixed for area impacts. The last eight impact
frames fade; interrupted flights and effects freeze and fade for 400 combat ms.
Editable recipes, service exports and packing metadata remain ignored under
`work/thornbriar-vfx/`; runtime needs only finished sheets and JavaScript.
