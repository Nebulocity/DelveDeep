# Build and deploy

The retired map builder and its tilesets are archived under ignored `project-backup/assets/`. Editor build/preview scripts have been removed. The game and Capacitor use `dist/`; the backup is for external storage and is not bundled into the game.

Use Node.js and npm from the repository root on Windows. `npm ci` installs locked dependencies; `npm run dev` starts Vite. `npm run build` generates `dist/`; `npm run preview` serves that build. The source root is the repository root, and `main.js` plus `config/gameConfig.js` start Phaser. Do not edit generated `dist/` or `node_modules/` as source.

For Android, run `npm run build`, then `npx cap sync android`. Open the Android project in Android Studio or run `cd android` and `.\gradlew.bat assembleDebug` in PowerShell. The Capacitor config bundles `dist/` with app ID `com.waywardkobold.app`. A packaged build should use bundled files, not a development-server URL. `npm run deploy` is a local helper that builds, syncs, opens Android Studio; it does not publish a store release.

The GitHub Pages workflow in `.github/workflows/pages.yml` builds on pushes to `0.1.9-SpellEffects` using the `/DelveDeep/` base path and publishes `dist`. It also supports manual runs through `workflow_dispatch`. Configure GitHub Pages to use GitHub Actions. The Pages base path is only for that workflow; run a normal `npm run build` again before Android sync. Browser, Pages and installed-app saves live in separate local-storage origins and do not transfer automatically.

The repository's `github-pages` environment also restricts deployment branches. When changing the workflow branch, add that exact branch to the environment's allowed deployment branches. Updating the YAML trigger alone does not update the environment allowlist. A successful build followed by an immediately rejected deploy job can indicate a missing branch policy. The allowlist includes `0.1.9-SpellEffects`; keep the existing environment protection rules.

Each Vite build embeds a unique build ID as metadata. Rebuilding or installing an update preserves profile and leader progression through the existing save keys and migration paths. Reset Progress remains an explicit player action.

`npm test` runs all maintained direct Node checks under `tests/` in separate processes. Focused checks can also run directly, for example `node tests/delve-selection.test.js` and `node tests/class-abilities.test.js`. Browser checks use `npm run test:visual`; there is no lint script. A build checks bundling, while a phone review is still needed for touch, text, haptics and video playback.

## Versioning and APK names

Use JDK 21 for the Gradle 8.14.3 wrapper and Capacitor 8 Java 21 sources. Java 25 is not supported by this wrapper. In Git Bash, select the installed JDK before building:

```bash
export JAVA_HOME='C:/Program Files/Java/jdk-21.0.12'
export PATH="$JAVA_HOME/bin:$PATH"
npm run build:android
```

Adjust JAVA_HOME to the actual installed JDK 21 folder. The build:android helper builds the web assets, syncs Android, then assembles the debug APK on Windows. Running Gradle alone does not rebuild or sync the web game.

package.json version is the shared human-readable release version. Android reads it during Gradle configuration; package-lock.json should match. The current version is 0.1.10. For the next version, run `npm version 0.1.11 --no-git-tag-version` from the repository root. This updates both npm files without creating a commit or tag. Branch names describe development work and do not change the release version automatically.

Debug APK filenames use `DelveDeep-<branch>-<eight-character-commit>.apk`. The full branch name is used, with unsafe filename characters replaced by hyphens. Filenames omit the package version, dirty marker and debug suffix. Rebuilding on the same branch and commit overwrites that filename even if uncommitted source changes differ. Detached HEAD uses detached for the branch; source archives without Git use detached and unknown.

Android debug versionName still includes the package version, branch description, commit and dirty marker. A leading version plus hyphen is removed from its branch description to avoid repeating it. The commit identifies the base commit, not the exact uncommitted contents. Release versionName stays at the package version and release output naming stays at the default.

Example: `0.1.3-ui-improvements` at commit `a1b2c3d4` produces `DelveDeep-0.1.3-ui-improvements-a1b2c3d4.apk` in `android/app/build/outputs/apk/debug/`.

APP_VERSION_CODE in android/gradle.properties is the Android update number, currently 14. Increase it before distributing a new update and keep it higher than every build already shipped to that audience. Do not derive it from branch names or Git commit counts. Equal codes can replace a sideloaded build; lower codes are normally rejected. No automatic counter is modified during a build.

Keep applicationId com.waywardkobold.app and the signing certificate consistent to update an installed APK. Same-computer debug builds normally share the debug key; release builds need a separately managed persistent signing key. Switching debug/release certificates prevents replacement even with matching versions.

Android updates preserve app storage, and new web builds now retain saved progression. BuildSave records the current Vite build ID only as metadata. Profile and leader saves keep their existing keys and normal migration paths. Reset Progress remains an explicit player action. Keep the application ID and signing certificate unchanged when updating an installed APK.

The loading overlay shows Loading with cycling dots above the left edge of the progress bar, and the web build's branch-plus-commit name above its right edge. Vite embeds this label in HTML before JavaScript loads. Rebuild and sync before packaging so it matches the source packaged in the APK.



## Google Play release bundles

Use `npm run check:android:release` to verify private signing settings, then `npm run build:android:release` to build, sync, and package a signed AAB. JDK 21 is required. Release packaging fails without a valid upload key; debug packaging does not require one. See [Google Play release preparation](GOOGLE_PLAY_RELEASE.md) for keystore setup, secrets, internal testing, version codes, and debug-to-Play save preservation.

