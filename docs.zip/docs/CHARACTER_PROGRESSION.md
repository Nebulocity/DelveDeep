# Character stats and progression

`config/characterProgression.js` contains the authored starting totals and archetype growth. `game/CharacterStats.js` rebuilds runtime stats and calculates percentage skill potency. Existing kit timing and movement settings remain in `data/classes.js`; createAdventurer applies the new stat profiles after character overrides.

Character stat tooltips use the requested concise wording in `data/statDescriptions.js`, without conversion formulas. The Strength tooltip mentions Block for tanks; the existing implementation below still grants Strength-based Block to all classes. This wording change does not change progression mechanics.

## Starting totals

The supplied level-1 totals already include the starting attributes. Attribute conversions apply to gains over those starting values, including gear bonuses. They are not added a second time at level 1.

| Profile | Health | Mana | Armor | STR | AGI | CON | INT | WIS | Attack Power | Spell Damage | Spell Healing |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Tank | 500 | 0 | 100 | 20 | 20 | 20 | 10 | 10 | 250 | 0 | 0 |
| Dawnwarden | 500 | 250 | 100 | 20 | 20 | 20 | 10 | 40 | 250 | 150 | 150 |
| Melee | 350 | 0 | 50 | 30 | 30 | 15 | 10 | 10 | 500 | 0 | 0 |
| Ranger | 350 | 0 | 50 | 30 | 30 | 15 | 10 | 10 | 500 | 0 | 0 |
| Mage | 150 | 500 | 50 | 15 | 15 | 15 | 40 | 30 | 50 | 500 | 350 |
| Healer | 250 | 500 | 30 | 15 | 15 | 20 | 30 | 40 | 100 | 350 | 500 |

All profiles start with Speed 100, Hit Chance bonus 0%, Crit Chance 0%, Crit Multiplier 1.3x, Happiness 80%, and zero clears. Tanks start at 5% Dodge and 5% Block; Gladiator starts at 10% Dodge and 0% Block. Melee, Ranger and Mage start at 2% Dodge and 2% Block. Healers start at 2% Dodge and 0% Block.

## Per-level growth

| Profile | Natural Health | Natural Mana | STR | AGI | CON | INT | WIS |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Tank | 20 | 0 | 1.5 | 0.5 | 2 | 0.25 | 0.5 |
| Dawnwarden | 18 | 10 | 1 | 0.5 | 1.5 | 0.5 | 1.5 |
| Melee | 12 | 0 | 2 | 1.5 | 1 | 0.25 | 0.25 |
| Ranger | 10 | 0 | 1 | 2 | 0.75 | 0.25 | 0.25 |
| Mage | 6 | 15 | 0.25 | 0.5 | 0.5 | 2 | 1 |
| Healer | 8 | 15 | 0.25 | 0.5 | 1 | 1 | 2 |

Fractional attributes are retained internally and shown as whole numbers in Character Stats. Constitution gains add 10 Health and 10 Armor. Strength gains add 8 Attack Power. Scoundrel and Ranger also gain 6 Attack Power per Agility. Intellect gains add 8 Spell Damage; Wisdom gains add 8 Spell Healing. Mana users gain 5 Mana per Intellect and Wisdom in addition to natural level growth; non-mana users retain zero Mana. Crit Multiplier and Speed have no level growth. Optional example passives in the references, such as Mage Wisdom-to-damage conversion, are not authored class features.

## Equipment level requirements

Common items require character level 1; Uncommon items require level 10. Rarity requirements live in `data/items.js`; future Rare, Epic and Legendary requirements remain unauthored and unavailable until configured. Equipment checks enforce class, level and potion-resource compatibility. Restoring an under-level equipped item clears its slot reference while preserving the owned copy, instance ID and enchantment in inventory. Detailed attribute gains use the current progression calculations, showing the selected character's level before other equipment, or class-specific level-1 gains in unassigned inventory and shop inspection.

## Equipment level requirements

Common items require character level 1; Uncommon items require level 10. Rarity requirements live in data/items.js; future Rare, Epic and Legendary requirements await authoring. Restoring an under-level item clears its equipped slot while keeping the owned copy and enchantment in inventory. Equipment inspection uses current attribute conversions for the selected character's level before other equipment, or class-specific level-1 values in unassigned inventory and shops.

## Combat and persistence

Damage/healing potency is a percentage of the relevant stat. Basic attacks use Attack Power; basic Mend uses its configured percentage of Spell Healing. Replacement damage-linked healing applies its independent percentage to actual HP removed, excluding overkill, without a second Healing-to-Damage stat conversion. Existing saved encounters retain the former conversion. Non-casters with zero Spell Healing have zero base self-healing until they gain that stat.

The displayed Hit Chance is a bonus over 90% base accuracy. The total rating can exceed 100%; an enemy's optional `minimumAccuracy` may require such a rating. Healing skips accuracy. Armor provides physical reduction equal to `Armor / (Armor + 400)` and does not mitigate damaging spells. Speed scales action cooldowns and windups relative to 100; movement retains the kit's movement setting.

Saved levels, XP, skill points/ranks/loadouts, happiness, clears and supported owned gear instance IDs persist. Derived stats rebuild from level and equipped gear. Inventory restoration translates recognized old item/enchantment IDs to their current catalog replacements, then reconstructs names, compatibility and bonuses from current definitions. It does not retain old Apprentice Focus or fractional-armor stat data. Current enchantments are added once, potion charges remain intact, and repeated loading cannot stack bonuses. Retired enchantment definitions are absent from active stock and runtime lookup tables.

## Monster stat options

Every exported monster in `data/enemies.js` has the same 20 stat fields as Character Stats. `game/MonsterStats.js` supplies defaults; individual definitions can override Level, Health (`maxHp`), Mana (`maxMana`), Armor, Dodge, Block, Speed, the five attributes, Hit Chance, Crit Chance, Crit Multiplier, Attack Power, Spell Damage, Spell Healing, Happiness and Delves Cleared (`delvesCompleted`). Monsters carry these fields into battle and show them when inspected.

Monster totals are authored starting totals, including any starting attribute contributions. They do not inherit an adventurer class growth profile or gain XP. Happiness and clears are available metadata; monsters do not train skills or earn party clears. Default Armor, Dodge, Block, Mana and attributes are zero; Speed is 100. Health, attack power and crit values can be overridden per archetype. The default Hit Chance bonus is 10%, retaining monsters' previous 100% accuracy while using the same 90% base accuracy and chance caps as characters.

`config/slimeBalance.js` supplies Slime tuning, and `config/monsterCatalog.js` applies the revised 24-monster roster totals and named skills before normalization. Catalog Health, Armor, Attack Power and basic reach take priority. Other shared fields retain existing profiles and defaults. Spell Damage defaults to Attack Power; an optional sixth catalog entry overrides spell stats (Hedge Mage has 128 Spell Damage and 64 Spell Healing). Monster level matches the recommended destination level without adding hero growth. Missing Quarry, Watch and named skill details use provisional potency and timings. Cave Slime and Elder Slime keep their 180% slams and Elder Toxic Glob at 120%. Sovereign Crushing Slime Slam is a 100% single-target strike; its Toxic Glob is a 180% target-centered circle. Consume is 300% physical potency, 690 damage before defenses, and cannot critically hit.

Thornbriar Hollow non-boss waves additionally apply `config/thornbriarBalance.js` when creating live enemies. These local totals target varied level-5 parties with cheapest compatible Common weapons/armor and untrained starters. Ruffian/Lasher/Hedge Mage Health is 1680/2800/2240 and power is 3, with existing Armor and percentage skills. Boss-wave escorts and Rongar retain catalog totals before their existing preparation scales; restored battle units retain saved stats. Rongar's new Belch is a player-response cast with a 4.5-second warning, fixed 400-unit caster-centered area and 900% Spell Damage potency. See THORNBRIAR_BALANCE.md.

Monster physical attacks now respect Armor and Block on either side. Spell attacks bypass both. Existing abilities default to physical damage, preserving their prior treatment; set `damageType: 'spell'` for a damaging spell. Existing flat ability powers are converted to percentages of their starting Attack Power or Spell Damage at export. New skills may explicitly use `powerUnit: 'percent'`. Their runtime potency uses the same `abilityPower` calculation as characters. Set `basicAttackDamageType: 'spell'` to make a monster's basic attack use Spell Damage instead of Attack Power.

Mana costs and regeneration work for monsters. An ability with `effect: 'heal'` targets the living monster with the lowest injured health fraction and uses Spell Healing, shared crit rules and its mana cost. Speed scales attack and ability cooldowns, windups and area telegraphs. It remains separate from movement speed.

Monster AI checks `primary`, then `secondary`. Monsters authored with `boss: true` also check an optional `tertiary` slot afterward. Each slot has its own cooldown and mana cost. A damage skill with `telegraph` uses the existing ground-circle behavior and a default 220 logical-unit cast reach, overridable with `castRange`. The circle captures the threat target's cast-start position unless `areaCenter: 'caster'` captures the monster's position instead. Windup and telegraph describe one warning/cast phase, not consecutive waits. A damage skill without `telegraph` targets the current threat target. Healing skips the slot when no living monster is injured. Generic ability normalization, held inspection, Speed scaling, and battle snapshots preserve the third slot without changing the save version.

Slime Sovereign's tertiary Consume warns for six seconds, then hits living party members within 600 logical units of its cast-start position. It has no cast range gate, its cooldown is 16 seconds, and its mana cost is zero. Interrupt cancels the pending action, so the delayed hit cannot resolve. Its damage uses the existing physical defenses. Consume sets `autoAvoid: false` so allies do not solve it through automatic mechanic avoidance; manually moving outside the warning still avoids the hit. Other warnings retain their existing automatic avoidance behavior.

## Chances and Block

Gained Agility adds 0.08% Dodge and 0.05% Hit Chance bonus. Gained Strength adds 0.05% Block. Each gained AGI, INT and WIS contributes 0.05% to one shared Crit Chance for attacks, spells and healing. Starting attributes are already accounted for by the supplied starting chances.

| Chance | Soft cap | Hard cap |
| --- | ---: | ---: |
| Dodge | 20% | 30% |
| Block | 25% | 35% |
| Crit | 25% | 40% |
| Hit bonus | 15% | 20% |

Above a soft cap, each additional percentage point contributes 0.25 percentage points, up to the hard cap. Attribute and gear bonuses combine before capping, without applying caps twice on restoration or equipment recomputation. Temporary crit and dodge bonuses also respect their hard caps.

A successful Block doubles total physical Armor mitigation rather than adding a second reduction after Armor. At 100 Armor, normal mitigation is 20% and blocked mitigation is 40%. At 400 Armor, blocked mitigation reaches 100%; reduction is capped there. Damaging spells bypass Armor and Block. Existing reductions and shields still apply afterward.

Battle Cancel Farm and Retreat controls require stone confirmations. Dialogs pause combat while open and restore the prior pause state when dismissed. Confirmed farm cancellation finishes and pays the current fight before returning to camp; Retreat retains its existing encounter reward rules and never deducts Renown Points. Character and Renown level gains stop at 50; see RENOWN_PROGRESSION.md.

## Delve preparation and XP caps

Pineshire starts at levels 1/5/10/15/20/25 and caps XP at levels 5/10/15/20/25/30. Thornbriar and Dolmark target level 10 and 15 bosses respectively, class-compatible Uncommon gear with best Common fallbacks where unavailable, four equipped skills and all ten/fifteen earned SP spent through legal purchases. The other Delves retain full Common gear and respectively 2 rank-2 (Slime), 3 rank-3 (Quarry), 2 rank-4 (Watch) or 3 rank-4 (Abyss) equipped abilities pending their balance passes. These are preparation targets, not entry locks. config/delveBalance.js applies local Health and power scales to fresh spawns after the Thornbriar non-boss overrides. Only the final boss wave receives boss scales; Abyss guardians remain progression waves. Monster inspection levels follow the starting or final-boss target without adding hero stat growth. Existing recorded saved-unit stats remain intact.

See [XP progression](XP_PROGRESSION.md) for every cost through level 50, difficulty hour budgets, mixed-party Gold and materials-only farming.


