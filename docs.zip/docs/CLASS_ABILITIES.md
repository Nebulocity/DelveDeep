# Class abilities

The replacement catalog is defined in data/replacementAbilityCatalog.js and filtered by data/replacementAbilities.js. It contains 169 class abilities and 24 generic abilities across fourteen classes. Two physical Restore generics are reserved because no current physical role permits Restore. Class training lists apply per-class generic exclusions as well as role permissions.

The fourteen classes and fifteen roster characters include Alhanna of Runedancer. Existing characters retain their identities, stats, gear and movement. New encounters use replacement abilities exclusively. Former kits remain available only to existing saved encounter definitions and compatibility tests.

## Category permissions

| Role / type | Primary | Secondary | Tertiary |
| --- | --- | --- | --- |
| Physical tank | Protect | Assault | Prepare |
| Magical tank | Protect | Assault | Restore |
| Magical melee (Runedancer) | Assault | Protect | Prepare |
| Physical melee | Assault | Prepare | Protect |
| Physical ranged | Assault | Prepare | Protect |
| Magical ranged | Assault | Prepare | Restore |
| Magical healer | Restore | Protect | Assault |

An absent category is unavailable, including its generic abilities. Generics must also match physical or magical type. Small linked effects may accompany the main purpose; standalone healing remains Restore and standalone shields remain Protect, except the explicitly authored Prism Shields preparation.

## Training and starters

Every class begins with exactly three free, equipped rank-1 abilities: one class ability in its Primary category, one in Secondary, and one eligible generic, except mages and Runedancer, whose third class starter is listed below. Four equipped slots remain available, so the fourth skill must be trained. Learning rank N costs N SP. Rank-1 skills normally unlock at level 1; Soul Reclamation, Restore Spirit and Cocoon of Life require level 10 at minimum for every rank; ranks 2-10 require levels 5/10/15/20/25/30/35/40/45.

Gold uses the existing level, rank and Happiness rule: round upward to the next multiple of five after (20 + 5 × level) × rank × (1 + (100 − Happiness) / 100). The rank-10 level gate does not bypass the total SP required for training.

| Class | Primary starter | Secondary starter | Generic starter |
| --- | --- | --- | --- |
| Gladiator | Defiant Roar | Offensive Drill | Interpose |
| Oathwarden | Judgement | Righteous Blow | Hold the Line |
| Dawnwarden | Dawn's Shelter | Solar Strike | Life Anchor |
| Barbarian | Savage Swing | Adrenaline Rush | Cleave |
| Scoundrel | Sneak Attack | Stealth | Kick |
| Barmaid | Frying Pan | Spilled Drink | Hamstring |
| Ranger | Piercing Shot | Hunter's Mark | Lacerate |
| Umbral Mage | Shadow Bolt | Dark Meditation | Gloomburst (class) |
| Luminous Mage | Radiant Spear | Renewed Focus | Celestial Flow (class) |
| Crimson Mage | Magic Missile | Duplicity | Ritual of Replenishment (class) |
| Verdant Cleric | Nature's Touch | Nature's Embrace | Smite |
| Everbright Cleric | Holy Light | Sunlit Ward | Smite |
| Sanguine Cleric | Blood Mend | Vital Pact | Smite |
| Runedancer | Garnet Stride | Aquamarine Drift | Fluorite Sway (class Prepare) |

Barmaid can also train **Pan Drop!**, an Assault skill that stuns every enemy within three paces of her current position for three seconds at rank 1, with a 20-second base cooldown and no damage or Mana cost. It respects stun immunity and cancels affected enemies' pending actions. Its 300 ms windup and standard control-rank progression use combat time; duration grows to a six-second cap and cooldown decreases to 11 seconds at rank 10. Her three starters remain unchanged.

## Independent effects and rank scaling

Primary and secondary effects each have a percentage coefficient, power basis and cap. Numeric amounts use current Attack Power, Spell Power, maximum resources, or actual measured damage/healing as specified by the record. Percentage-point bonuses are distinct from percentage stat changes.

All damaging and healing spell effects now use `Caster Spell Power`. Effects that formerly used healing power explicitly carry `healing: true`, so the resolver still distinguishes a direct heal from damage. Each magical class has its own entry in `CLASS_HEALING_MULTIPLIERS` in `config/characterProgression.js`, initially 0.25. `config/healingBalance.js` applies that class's multiplier to marked coefficients and their caps once, before building rank tables. Shared magical healing abilities therefore use the receiving class's tuning. Inspection and combat use the same definitions, and saved encounters retain their recorded coefficients. Reference rows keep their original coefficients. At 500 Spell Power, the pre-rank reference outputs are 137.5 for Nature's Touch, 143.75 for Holy Light and 150 for Blood Mend; rank-table rounding produces 138, 143 and 150 at rank 1. Damage-linked healing, percentage-resource recovery, shields and basic Mend retain their independent coefficients. Temporary Spell Power modifiers strengthen marked healing and basic Mend once; damage-linked healing uses actual damage and a Spell Power-based cap.

New catalog definitions use ten explicit records built by `data/abilityRankCurves.js`, after healing tuning. Damage, healing and measured-output coefficients add approximately 15% of starting potency per rank, rounded to 0.05 coefficient steps with a 0.05 minimum. Stat percentage changes generally add five percentage points; larger Armor changes add ten. Chance changes add one percentage point and retain the character's final chance limits. Quick Casting progresses from 20% to 65% in five-point steps and retains the separate 100 ms combat windup minimum.

Cooldowns of at least 18 seconds decrease one second per rank; shorter cooldowns decrease half a second. Neither falls below the authored floor or half the starting cooldown. Ordinary duration steps are one second, with half-second steps for protection/control. Periodic and channeled durations stay fixed so training does not dilute their tick output or lengthen a blocking channel. Enemy control growth has a conservative ceiling tied to the shortest cooldown. Authored duration caps remain in force.

Rejuvenation Aura restores 30% of caster maximum Health at rank 1 through 120% at rank 10, adding ten percentage points per rank over its unchanged six-second duration. Potion packs still cannot exceed capacity. Restocks without an existing damage preparation add a one-use next-physical-ability bonus of 5%-50%, usable within eight seconds, so training full-pack refills has a benefit. Barbarian Preparation retains its own growing preparation instead. Costs, training gates, permission rules, item capacity and once-only restrictions stay unchanged. Learned ranks are retained; existing saved encounter definitions without rank tables keep their historical curve. Speed still adjusts action timing. These stronger ranks have preliminary checks only; regional balance and physical-device review remain deferred at the user's request.

Periodic damage/healing coefficients describe total output divided among ticks. The final partial interval resolves at expiry. Damage-linked healing uses actual HP removed, excludes overkill and does not add a second critical or Healing-to-Damage stat ratio. Linked effects apply their own listed caps.

Binary rules, Health costs and item capacity do not grow indefinitely. Health costs are a fixed percentage of current HP, bypass defenses and cannot be lethal. Unsafe casts are skipped. Mana costs are a percentage of maximum Mana except Prism Shields, which costs a fixed 20 Mana. Setup bonuses are consumed once at action commitment and cannot create recursive casts or resource returns.

All magical class and generic abilities have positive Mana costs, including mana recovery. Devotion, Essence Drain and Infusion cost 2% of maximum Mana; Dark Meditation costs 3%. Their rank-1 recovery can still exceed the payment, and Infusion also retains its 6% current Health cost. Mana costs remain fixed across ranks, are rounded to whole Mana at battle entry, and are paid once when casting starts. Insufficient Mana prevents casting; natural Mana regeneration continues to permit recovery after depletion. Existing saved encounters retain their recorded costs.

## Targeting, reactions and persistent mechanics

All movement and areas use continuous floor coordinates. Workbook cast ranges and radii use logical arena units; runtime cast range is converted to paces at 100 units per pace. Adjacent is 100 units and Near is 240. Lines and cones use their actual directions. Teleports, charges, escapes, decoys and the Neutral Ground formation respect authored floor boundaries, occupancy and player Hold orders.

ReplacementAbilitySystem handles independent effects, shared stat modifiers, nonstacking preparations, control, periodic restoration, placed zones, decoys, reactive attacks, cooldown manipulation, resurrection and lethal-hit protection. Effect records store combat-clock timestamps and owner IDs. Snapshot version 1 remains supported, with optional decoy records and saved per-unit effect state. Visible and background combat share the same model.

Potion restoration grants temporary combat charges for the pack equipped at entry, even after its final permanent charge is consumed. Credits cannot exceed pack capacity, create saleable inventory or travel home. Restocking is once per wave and excluded from cooldown resets. Once-per-encounter usage survives death and revival. Quick Pour spends actual or temporary Health Potion charges on a critically hit real ally.

Current supplied pixel effects are reused for matching replacement actions. Persistent fields show their floor footprints. Decoys reuse the supplied character art, remain outside party and reward lists, and do not generate party-death notifications.

## Save migration

On the first load of a former trained catalog, preserve level, XP, Happiness, gear, clears and world progress. Refund spent SP, excluding free starter rank 1; clear retired loadouts and grant the new starters. Gold receives a deterministic minimum-price credit at each rank's earliest trainable level and 100 Happiness because historical purchase prices were not recorded. Persist abilityCatalogVersion 2 and the refund summary so loading again cannot pay twice.

An already saved encounter finishes with its saved ability definitions. Its roster is respecialized separately, so subsequent encounters use only the replacements. Old helpers and the retired reference in changelog are compatibility material, not instructions for authoring new skills.

Basic attacks, basic Mend, Party Leader tactics and monster catalogs remain outside this replacement. In new encounters, all three healer classes also pay 2% of maximum Mana for basic Mend, once at cast commitment; insufficient Mana prevents it. Saved encounters retain their recorded Mend cost. Encounter and class balance needs fresh physical-device playtesting after the catalog change.

New healer encounters regenerate 2 Mana per combat second instead of 8. A level-1 Mend costs 10 Mana and restores 40 HP, so continuous use at its 1.6-second cooldown spends Mana faster than regeneration. Existing saved encounters retain their recorded regeneration and ability potency. This focused healing pass does not change boss tuning or guarantee that every solo strategy is defeated; party and solo Slime Sovereign playtests remain needed.

## October 15 class access balance

Mages cannot learn Life Anchor or Rejuvenation Aura. Cost of Life and Dark Rejuvenation are retired. Soul Reclamation belongs only to Sanguine Cleric and unlocks at level 10. Everbright Cleric gains Restore Spirit and Verdant Cleric gains Cocoon of Life at level 10. All three revivals start at 30% recipient maximum Health and 20% maximum Mana, cost 15% caster maximum Mana, have a 60-second cooldown and six-pace range, and are once per encounter. Soul Reclamation retains its 10% current Health sacrifice; the two new revivals have no Health cost.

Barbarian, Scoundrel, Ranger and Barmaid cannot learn generic Hold the Line or Interpose. Ranger and Scoundrel also cannot learn Cleave or Charge. Their other abilities and starters are preserved.

Lunar Alignment increases the next Assault ability's potency and reduces its Mana cost by a fixed 15% at all ranks. Prism Shields remains Prepare: a self shield with rank-1 absorption of 15% Spell Power, fixed 20-Mana cost, eight-second duration and 26-second base cooldown. Only destruction by damage triggers radiant damage at twice the shield coefficient to each enemy within two paces. Rank scaling preserves that two-to-one ratio and the eight-second duration.

Loading existing roster saves removes unavailable abilities and refunds their trained SP plus deterministic minimum-price Gold, excluding a former free starter rank 1. An equipped Life Anchor mage starter changes to the new class starter in that slot. Other removals leave empty slots. Cleaned saved ranks prevent duplicate refunds; unrelated ranks and equipment remain intact. Existing battle snapshots retain their recorded abilities and handlers, including retired skills.
