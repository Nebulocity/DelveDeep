# Dolmark balance pass

Updated 2026-10-13. Dolmark uses the same actual-combat protocol established in THORNBRIAR_BALANCE.md. The subsequent Quarry, Watch and Abyss pass is documented in REGIONAL_BALANCE.md.

## Intended experience and authored changes

Supported five-member parties have one tank and one or two healers, with varied damage characters. Entry-level progression and repeated farming should survive without intervention or with ordinary Attack, Move and brief Hold orders. Missing-role parties are separate stress cases.

Fresh ordinary Dolmark monsters use 70% of catalog Health and 25% of catalog Attack Power and spell power. Armor, reach, skills, movement, authored composition, fifteen progression waves, wave-fifteen farming and rewards are unchanged.

| Ordinary monster | Health | Armor | Attack Power |
| --- | ---: | ---: | ---: |
| Den Warden | 2,100 | 285 | 9.5 |
| Den Protector | 3,220 | 310 | 13 |
| Den Colossus | 4,340 | 375 | 19 |

The final boss wave retains its 85% Health scale and uses 55% catalog power, including escorts. Silvanark has 35,700 Health, 420 Armor and 178.75 Attack Power. Forest Quake increases from 300% to 600% physical potency, giving 1,072.5 nominal damage before Armor, Block, critical multipliers and other reductions. Its six-second warning, sixteen-second cooldown, fixed caster-centered 500-unit area and manual-response requirement remain unchanged. Root Lance and Shatterbark keep their potency and timing.

Preparation advice now specifies level 15, compatible Uncommon gear, best Common fallbacks where the catalog lacks eligible Uncommon gear, all four ability slots and earned SP spent on ranks. Stable encounter IDs, level cap, checkpoints, XP, drops, save schema and recorded active monsters are preserved. New spawns receive the new tuning; saved units retain their recorded stats and abilities.

## Fixtures and real combat

The maintained browser harness is tests/visual/dolmarkSimulation.js, with dolmark-simulation.spec.js and dolmark-response.spec.js. It runs the actual Phaser AI, movement, timers, skills, threat, damage, recovery and rewards through the existing 50 ms replay steps. It excludes the death-free estimated offline farm system. Every fixture resets the scene clock, owned equipment and roster, seeds initialization and combat RNG, stops the game loop/background timer and suppresses tactics, potions and persistent test writes.

Progression/farm preparations use departure levels 10/12/15, cheapest purchasable class-compatible Common weapons and armor, and three free rank-one starters. All fifteen waves carry actual resources forward; the farm begins from camp without a refill. Combat retains departure stats when rewards level the roster, so separate midpoint/cap fixtures cover refreshed visits.

For direct comparison this retains the pilot's composition generator: its alternating tank index associates Garrick with one-healer parties and Aldren with two-healer parties. Healer identities and random damage characters vary, and the maintained regression includes all fourteen adventurers. These cohorts do not exhaust every tank/healer-count combination; category averages should not be interpreted as an isolated effect of adding a healer.

Boss preparations use level 15 with full resources and the game's readiness reset. Cheapest purchasable compatible Uncommon weapons and armor are equipped, plus compatible Uncommon accessories. Barbarian, Ranger and Scoundrel use their best purchasable Common armor because the catalog lacks compatible Uncommon armor. Barbarian has no compatible accessory and the catalog has no Common accessories. Reward accessory grants and funded training do not establish shop availability or affordability.

Both builds learn a fourth class skill in the primary starter's category and legally spend all fifteen SP through real purchase rules. Balanced slot ranks are 3/3/2/2; specialized ranks are 4/3/1/1. The reports retain exact skill IDs, ranks, owned gear, training Gold and zero unspent SP. The assisted boss policy uses the real Interrupt tap handler only for Forest Quake, after 1.5 seconds. Farm commands periodically focus an enemy, move an injured ally toward the party and briefly Hold, releasing manual orders after two combat seconds.

## Boss measurements

The final native cohorts each use twelve supported parties and four combat seeds. Party stride/seeds are 104729/[11,22,33,44] and 1/[1,2,3,4]. Each has both unattended skill builds and a matched balanced build with delayed Quake interrupts. These results supersede the earlier 50%-power candidate.

| Prepared boss condition | Victories | Win rate | Mean character deaths |
| --- | ---: | ---: | ---: |
| Unattended, both builds | 42 / 192 | 21.9% | 4.03 |
| Forest Quake interrupts | 88 / 96 | 91.7% | 0.90 |

This meets the difficult-unattended target and shows a substantial leadership benefit. Assisted success exceeds the initial provisional 70-85% target; low-damage parties still suffer deaths and occasional wipes from ordinary pressure even when Quake is interrupted. Composition and critical/Block RNG matter.

## Ordinary candidate selection

The baseline supported cohort had eleven wipes in twelve progression/farm preparations, while all twenty-four prepared unattended boss fixtures won. Ordinary ten-minute sweeps at 70% Health and 40% power appeared safe across varied parties, but a one-hour commanded trial exposed a supported-party wipe after forty-three repeat clears. The rejected batch was stopped after confirming that failure; its full per-wave records were not exported. The failure index, seed and console result remain recorded locally.

Focused matched one-hour reruns of that same party index and seeds survived at 30% power, but reached only 32.1% Health. At 25% power both reruns survived with a 63.5% minimum. The selected authored value therefore uses 25% power for greater sustained margin. Final broad endurance is split into two independent browser batches with the same original party indexes, roster seed and combat seeds; splitting delivery does not alter the fixtures.

## Final farm measurements and XP

The authored endurance cohort uses twelve supported parties, stride 1, combat seeds 1/2, and both unattended and commanded farming at departure level 10. Its forty-eight simulated farm hours completed 4,817 repeated clears with zero deaths and a worst measured Health low of 59.9%, including unfinished current fights. All forty-eight progression sequences reached camp without deaths. Mean fight time is 27.9 seconds and mean full cycle is 35.7 seconds.

The maintained regression adds forty-eight supported progression/farm fixtures at departure levels 10/12/15, with 887 repeat clears and no deaths. Its worst farm Health low is 70.9%. Unattended cycle means are 32.5/31.3/29.8 seconds by departure level. Combined, ninety-six supported progression sequences reached camp without deaths. The no-tank stress party survived all four one-hour conditions. The no-healer party had two deaths in one unattended seed and wiped under commands in both seeds; its other unattended seed survived. Missing-role boss fixtures also failed in the maintained regression.

The existing 1,694-XP band and provisional sixteen-hour target are unchanged. Fifteen ordinary clears award 45 XP, leaving 1,649 farm XP. At the endurance mean cycle this implies about 16.4 farm hours. Individual party mean cycles range from 26.4 to 52.9 seconds, implying about 12.1 to 24.2 hours while holding departure stats constant. Gear, training, departure-stat refreshes, offline estimates and class throughput can change those estimates. Revisit the shared economy after the remaining Delves receive their passes rather than changing the XP curve from this encounter alone.

## Validation and reproduction

The final maintained regression covers six varied supported parties at departure levels 10/12/15 plus commanded level-10 farming. All forty-eight supported progression sequences reached camp without deaths, and all repeated-combat survival and Health-margin assertions passed. Both boss builds have four equipped abilities and zero unspent SP; the unattended/intervention outcome assertions pass. Separate response tests passed for phone-sized advice, pause, the fixed warning center, cancellation of delayed damage and exact seeded equality across repeated scene visits.

Run npm run test:visual -- dolmark-simulation.spec.js --workers=1 for the maintained regression and dolmark-response.spec.js for phone-sized preparation advice, pause, fixed warning center, canceled delayed damage and repeated-scene deterministic equality. The Node check is tests/dolmark-balance.test.js.

Exploratory JSON DELVE_SIM_OPTIONS, DELVE_SIM_LABEL and DELVE_SIM_VALIDATE work like the Thornbriar pilot. Use farmMs: 3600000 for one-hour endurance. Raw reports, screenshots, infrastructure helpers and review output remain ignored under output/qa/dolmark-simulation/ and .tmp/.

This environment restricts localhost connections and resolves some source paths with EPERM. The ignored local QA adapter supplies Vite-transformed workspace files to the cached Playwright browser through request fulfillment, with Phaser bundled to ESM. It changes delivery only; the maintained simulation and response assertions execute unchanged. A local Vite configuration preserves symlink paths and restricts dependency discovery to index.html. The production build uses npm run build -- --config .tmp/dolmark-vite.config.js here. Normal reproduction does not require the ignored adapter.

The complete Node suite is 82/85, including the new Dolmark check. The same three pre-existing failures remain: replacement-abilities' HUD fixture omits GameState, selective-travel expects no Wrath projectile, and shop-services expects equipped gear to remain in sale rows. Physical Pixel 9 review remains pending. No finite simulation proves farming can never cause a death; survival claims apply to the recorded preparations and command policy.


