# The Everdeep

Updated 2026-10-05. Implemented in `game/Everdeep.js`, `game/EverdeepState.js`, and `scenes/EverdeepScene.js`.

## Access and expeditions

- The Pineshire entrance unlocks after The Sunken Watch boss, alongside the first region's Void Portal branch. The current illustrated map and stable location IDs are described in WORLD_MAP.md.
- Multiple expeditions may run concurrently. Each costs one 120 Gold writ, lasts at most two hours of real elapsed time, and resolves one abstract wave every two minutes, up to 60 waves.
- Each expedition snapshots exactly five distinct roster adventurers with the usual role limits: at most one Tank, two Healers, and four DPS. Character levels and equipment power are frozen at departure. The same adventurers can join multiple expeditions and remain playable in ordinary Delves and Portals.
- Everdeep does not consume equipped potions, change HP or happiness, award ordinary Delve clears, or advance Party Leader tactics.
- A failed wave ends only that expedition. Every tenth successfully cleared wave earns a chest, up to six. Outcomes remain deterministic from each persisted seed.
- Recall settles completed waves, stops the selected expedition, and retains earned chests. Writ and unused time are forfeited. The screen confirms recall and explains the cost.
- Chests may be claimed while descending or after stopping. Claims are sequential and grant Gold, materials, and gear with their claimed index in one profile save. A stopped expedition can be dismissed only after all its earned chests are claimed. Starting another expedition does not require claiming or dismissing earlier ones.

## Screen and timers

- The violet Carved Stone screen uses an expedition list on the left and party preparation or expedition details on the right. Both expedition and roster lists paginate to keep cards and touch targets inside the landscape viewport.
- Details show the departure party, cleared waves, Next Wave, Time Left, six chest milestones, and the next chest's actual rewards.
- Both timers refresh from wall-clock timestamps every second without reconstructing buttons. Slow Phaser rendering and time away do not extend the expedition. Resume settles all elapsed waves for every expedition.
- The screen clamps against its last observed time to prevent a backward clock jump from increasing timers during that visit. Device time remains the authority across reloads.
- Profile saves occur on actual wave/stop changes, starts, recalls, claims, and dismissal. Idle timer ticks do not write the profile.

## Save compatibility

`everdeep` uses schema version 2: `{ schemaVersion: 2, runs: [...], totals: { runsStarted, chestsClaimed } }`. Each run retains its prior ID, seed, party snapshot, timestamps, wave interval, rules and reward versions, resolved wave, stop status, and earned/claimed counts. Version 1 `activeRun` saves migrate into a one-entry array without rerolling or losing aggregate totals. Invalid and duplicate entries are discarded on load. The existing fresh-progress-per-production-build rule remains unchanged.

## Existing tuning

Pineshire uses encounter levels 1-3 and existing threat, party-power and reward formulas. Current catalog rewards are Common weapons/armor. Higher rarity and reward item-level implementation remain future work; this UI/concurrency update does not alter reward balance or add regions.
