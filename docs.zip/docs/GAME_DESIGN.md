# Game design

## Core loop and player role

The player is a persistent Party Leader, separate from the five adventurers they command. Select a world-map location, choose a party and equipped leadership tactics, enter a delve, direct real-time combat through waves and a boss, then collect rewards and advance Player progression, Character progression, and map progress. The battle is a compact free-moving 2D arena, not a turn-based grid, with continuous distance-based ability targeting and walkable boundaries specific to each environment.

## Party and classes

A party has five adventurers, at most one Tank, two Healers and four DPS. DPS include melee and ranged roles. Current classes and individual kits are defined in `data/classes.js`; the provisional tuning and saved roster mappings are in [Class abilities](CLASS_ABILITIES.md). Character identity persists through roster IDs, experience, equipment and encounter history. Personality, rarity and event-driven happiness are longer-term ideas, not complete systems.

## Spell Power

Spell Power replaces separate Spell Damage and Spell Healing in new character stats, monsters, abilities and inspection. Mages and healers start at 500, Dawnwarden at 150, and other profiles at zero. Each gained Intellect or Wisdom adds 8 Spell Power; level-1 attributes are already included in the starting total. Both attributes retain their maximum-Mana and shared critical-chance contributions. Mages still regenerate extra Mana from Intellect, and healers/Dawnwarden from Wisdom.

Healing coefficients are tuned per class through `CLASS_HEALING_MULTIPLIERS`, initially 0.25 for each magical class. Rank curves and ability costs remain unchanged. The unified stat intentionally strengthens secondary spells and level growth; full regional balance remains to be reassessed. Existing roster saves rebuild power from class and level without losing progression. In-progress saved battles and frozen Everdeep parties retain their original recorded stats. Gear values and class restrictions await the user's workbook revision. `Spell Power Bonus` maps to the catalog key `spellPower`; a temporary reader treats the larger of an item's old damage/healing bonuses as one bonus without editing that item.

## Combat commands

Adventurers acquire targets, move, attack, heal and cast by class. The player can select individuals or role groups, issue Move, Hold, Attack, Spread or Stack orders, and use equipped Party Leader tactics. A tapped floor position moves selected units and holds them at destination; tapping an enemy with a selected character issues Attack. Hold suppresses automatic repositioning while allowing actions in range. Spread and Stack use meaningfully different separation distances. Focus Fire favors a shared target while healers keep healing; an explicit healer Attack order resumes offense when no living ally is below 80% HP and persists until replaced or the target dies. Interrupts require a valid cast and capable character. See [Combat system](COMBAT_SYSTEM.md) for threat, spacing, HUD and exact order behavior.

## Encounters and progression

Difficulty describes each encounter within its region; the starting level sets its absolute progression tier. Difficulty selects normal wave rewards and encounter length: Easy 6, Difficult 10, Tough 16, Very Tough 24, Incredibly Tough 34, Impossible 50. Authored catalog compositions preserve their monster counts. Pineshire's route is Slime Cave (Easy, levels 1-5), Thornbriar Hollow (Difficult, 5-10), Dolmark Den (Tough, 10-15), Old Quarry (Very Tough, 15-20), Sunken Watch (Very Tough, 20-25), then Murmuring Abyss (Incredibly Tough, 25-30). Each boss opens the next road; Watch opens the branch to Everdeep and Abyss. The Abyss remains a Void Portal and now banks normal wave rewards and opens farm camps after waves 15 and 33. Its final boss is wave 34; earlier guardian boss flags do not end checkpoint progression. Verdant Tear retains its separate Unknown portal flow. Saved map IDs remain compatible. See [World map](WORLD_MAP.md) and [XP progression](XP_PROGRESSION.md).

Player progression covers the player's Renown Level, Renown Points, unlocked tactics, and equipped tactic loadout. A fresh leader starts at Renown Level 1 with 1 RP and no purchased tactics. First roster milestones at character levels 5, 10, 15 and onward grant one Renown Level and one RP globally per milestone. Each distinct ordinary final boss or Void Portal closure grants the same reward once; portals do not also pay a boss reward. Both level caps are currently 50, and retreat never removes RP. Leadership rarity gates are Common 1, Uncommon 10, Rare 20, Epic 40 and Legendary 50; Legendary purchases are blocked for future quest acquisition. See RENOWN_PROGRESSION.md for provisional prices and future premium design. Up to five tactics may be equipped across Assault, Protect, Restore, and Prepare. The Tactics screen scrolls each category's list as needed. Character progression covers each adventurer's experience, level, happiness, ability training, and equipment. Gold and world unlocks persist as shared progress. Weapon, armor, accessory, and potion slots are present. The workbook catalog defines equipment, materials, scrolls, and recipes; recipe discovery, costs, crafting, shop stock and resale follow those authored rows. All three shops buy owned gear, potion packs, materials, and scrolls; equipped items must be unequipped first. Future design ideas include deeper branching paths, Void Manifestations, roster rarity, morale events, consumables and more specialized parties. These are planned directions until implemented in source.

## Item reset

The retired item catalog and crafting data were cleared before the baseline catalog below was introduced. The Items screen shows owned supplies. Characters retain weapon, armor, accessory, and potion slots. A potion slot holds one pack of a single potion type with up to three uses. The old shared Healing Tonic inventory and Prepared Supplies tactic are retired; players who unlocked Prepared Supplies receive its Renown Point back. Recognized old item and enchantment IDs in supported inventory saves translate to current replacements. Their names, compatibility, prices and bonuses use the current catalog; unknown removed items are discarded. Character, Gold, world and tactics progression remain.

## Baseline catalog

The authored workbook catalog contains 41 equipment pieces, five enchantment scrolls, 24 materials, and 43 recipes, alongside the existing potion packs and two brewing recipes. Recipes have authored material counts, fees, and discovery rules; items without a buy price are not added to shop stock. Unique items without a stated acquisition rule remain catalogued but are not assigned invented drop sources. Stable workbook IDs, individual item copies, material counts, known recipes and equipment persist in the profile. The Items screen browses owned stock and recipe details.

## Starting equipment

Each class has three free starter abilities; ability definitions, starter kits, ranks and authored targeting values are sourced from the ability workbook. Numeric ability reach and area radii convert workbook distances at 100 logical units per measure. The class progression retains ten training ranks. Starting equipment and save migrations live in data/startingEquipment.js and game/Equipment.js.

## Planned item progression

Items use Common, Uncommon, Rare, Epic, and Legendary rarity. Normal pre-boss waves give equal Gold and XP per clear: 1/2/3/4/5/6 by difficulty. Gold does not grow with wave number. Guaranteed first-clear material counts remain unchanged. A saved camp unlocks after the last pre-boss wave and reopens there on later visits. Abyss has camps after waves 15 and 33. Camp offers the latest unlocked farm wave, leaving the Delve, and continued progression or the final boss. Farm XP and Happiness go only to adventurers alive when the wave clears, and Happiness remains capped at 100. Boss completion rewards remain separate and respect the same Delve level cap. Abyss uses ordinary wave banking and farm rewards while preserving its portal identity. Verdant Tear retains the separate portal flow.

Future loot rolls may add difficulty-based item rarities; bosses may grant fixed gear and material rewards. Accessories primarily come from Void Portals, cannot be crafted, and may appear as a very rare bonus drop from the highest normal difficulties. Void loot distribution remains separate and undecided. The Enchanter stocks and inscribes Minor Might (+1 Attack on weapons), Minor Mending (+1 Healing on weapons), and Minor Vigor (+6 HP on armor/accessories). A scroll costs 80 Gold or four materials to inscribe; applying it consumes the scroll and allows one enchantment per item. Disenchanting retains gear, removes its bonus, and randomly refunds two units from its four-material recipe without replacement. Blacksmith weapon stock costs 80 Gold and armor 100 Gold; gear and scrolls sell for half stock price. These prices and bonuses are provisional. Legendary items are reserved for major story progression.

While away during repeat farming, elapsed time and the recent average complete farm cycle determine completed waves. Until an average is available, use one wave per minute. Normal reward caps and material odds apply; offline farming causes no new deaths. Returning shows one plausible fight already underway with healthy, varied party resources and some authored enemies remaining. Existing fallen allies are not revived. Progression and boss encounters retain their combat outcomes.

| Farm difficulty | Gold per wave | XP per living adventurer | Happiness per living adventurer |
| --- | ---: | ---: | ---: |
| Easy | 1 | 1 | 1 |
| Difficult | 2 | 1 | 2 |
| Tough | 3 | 1 | 3 |
| Very Tough | 4 | 1 | 4 |
| Incredibly Tough | 5 | 1 | 5 |
| Impossible | 6 | 1 | 6 |

Every adventurer stops earning Delve XP and Happiness at the boss preparation level. Shared Gold is multiplied by the uncapped fraction of the selected party and rounded upward; it becomes zero when all are capped. Material rolls continue unchanged. XP grants clip overflow at the cap, including boss XP. Camp explains mixed-party reductions or materials-only rewards. Existing overleveled saves retain their level and banked XP. Selling materials, crafting and buying remain available. See [XP progression](XP_PROGRESSION.md) for the full level-50 plan and 4/8/16/32/64/128-hour farming targets.

Each cleared farm wave makes one independent roll per rarity, awarding one uniformly selected eligible environment material on success. A wave can award no materials or several rarities. These percentages replace the previous guaranteed 1/2/2/3/3/3 farm units:

| Farm difficulty | Common | Uncommon | Rare | Epic | Legendary |
| --- | ---: | ---: | ---: | ---: | ---: |
| Easy | 48% | 3% | 0% | 0% | 0% |
| Difficult | 42% | 6% | 2% | 0% | 0% |
| Tough | 30% | 15% | 4% | 0% | 0% |
| Very Tough | 15% | 30% | 8% | 1% | 0% |
| Incredibly Tough | 6% | 42% | 16% | 2% | 0.05% |
| Impossible | 3% | 48% | 32% | 3% | 0.75% |

The current catalog contains only Common and Uncommon materials. Rarities without eligible materials award nothing; configured higher-tier chances become usable when matching catalog materials are authored. First-clear wave rewards retain their guaranteed quantities and original pools: Common on Easy, Common and Uncommon above Easy. Delve Info lists both first-clear and farm possibilities, including Uncommon on Easy. materialEnvironments in authored levels selects catalog sources; reused encounters inherit it. Slime Cave and Dolmark Den use Caves, with Old Quarry inheriting Dolmark. Thornbriar Hollow uses Forests and Humanoid bandit loot, with Sunken Watch inheriting Thornbriar. Abyss farms draw from all existing gatherable Caves, Forests and Humanoid materials; Verdant Tear has no ordinary material pool. Crafted materials remain excluded, and saved inventory counts remain intact.
