# Google Play release preparation

Delve Deep uses com.waywardkobold.app, Capacitor 8, JDK 21, and Android API 36.
Account verification may prevent console setup and distribution, but local build preparation can proceed.
These commands prepare a bundle; they do not upload or publish it.

## Create and preserve the permanent upload key

1. Open android/ in Android Studio. Select Build > Generate Signed Bundle / APK > Android App Bundle > Next > Create new.
2. Save DelveDeep-upload.jks outside the repository in private storage. Choose alias delvedeep-upload, a strong password, and at least 25 years of validity. Use the same password for the store and key, as recommended by Android's signing guide.
3. Store the password in a password manager. Keep an encrypted backup of the keystore separately from the computer. A Git ignore rule is not a backup.
4. Copy android/keystore.properties.example to android/keystore.properties and enter the actual path and passwords. Use forward slashes for Windows paths. Java properties interprets backslash escapes; passwords containing backslashes must escape them as double backslashes. Leading password spaces also need escaping. Environment variables avoid properties-file escaping.
5. Do not commit the actual properties file or keystore. Never put secrets in package.json, gradle.properties, terminal arguments, screenshots, or chat.

For CI, the environment variables override the corresponding local properties:

| Property | Environment variable |
| --- | --- |
| storeFile | DELVE_UPLOAD_STORE_FILE |
| storePassword | DELVE_UPLOAD_STORE_PASSWORD |
| keyAlias | DELVE_UPLOAD_KEY_ALIAS |
| keyPassword | DELVE_UPLOAD_KEY_PASSWORD |

Relative storeFile paths resolve from android/. Debug builds need no release credentials.
The preflight checks required settings, file existence, passwords, private-key alias, certificate expiry, and rejects Android debug certificates. Direct release Gradle builds also run the check.

## Build on Windows

Select JDK 21 in the terminal first, adjusting the installation path if necessary:

```powershell
$env:JAVA_HOME = 'C:\Program Files\Java\jdk-21.0.12'
$env:PATH = "$env:JAVA_HOME\bin;$env:PATH"
npm run check:android:release
npm run build:android:release
```

The build checks signing, builds the web game with the normal base path, syncs Capacitor,
then packages android/app/build/outputs/bundle/release/app-release.aab.
An AAB is an upload artifact, not a file you install directly on the phone.
Android Studio's signed-bundle wizard is an alternative: its supplied credentials take priority as one complete set. The wizard does not require keystore.properties or DELVE_UPLOAD_* variables. Terminal builds still require those private settings. Do not create a second permanent key when retrying a failed wizard build; select the existing upload keystore.

package.json supplies versionName, currently 0.1.9. APP_VERSION_CODE in android/gradle.properties
is currently 10. Increase it before each subsequent Play upload, keeping it above every code
already uploaded for this package. Building does not increment the code or change the package ID.

## When verification completes

1. Complete any device-verification task; installing the Play Console app alone is insufficient.
2. Create Delve Deep as a Game. Choose Free if the download will be free with optional purchases/ads. Once offered free, an app cannot be changed to a paid download under the same package.
3. Keep com.waywardkobold.app as its permanent package name. If Google requests proof of ownership because earlier sideloaded builds used this name, follow the console's ownership process; do not replace the upload key with the debug key.
4. Open Test and release > Testing > Internal testing. Configure Play App Signing, normally with Google's generated app signing key, and upload the signed AAB. If you need a shared signing identity across stores, decide that before choosing a Google-generated key.
5. Add your phone's Google account to the internal-test email list, save the tester list, and review/roll out to Internal testing only. Complete any account or release requirements the console identifies.
6. Open the opt-in link on your phone with the listed Google account, join the test, and follow the Google Play installation link. The test is not discoverable through normal Play search.
7. Check launch, landscape layout, haptics, tutorial video, saving/relaunching, then distribute a higher-versionCode update and verify progress survives.

The upload key authenticates the AAB you send to Play. The Play app signing key signs the APKs
installed on devices. Record the Play app signing SHA-1/SHA-256 for future Google/Firebase
integrations; the upload certificate fingerprint is a separate identity.

## Preserve existing phone progress

The current debug APK and Play-delivered APK normally have different signing certificates.
They cannot update one another even with the same package name and a higher version code.
Uninstalling the debug app deletes its local data. Keep it installed until a save export/restore
route has been prepared if that progress matters. This task does not add save migration or cloud backup.
Local signing with the upload key also does not reproduce Google's app signing certificate.

## Scope of this milestone

This prepares signed distribution only. Billing, rewarded ads, cloud saves, consent, and purchase
verification are separate integrations. Internal testing supports up to 100 testers. Billing license
testers are configured separately later; internal-test membership alone does not make purchases free.
Development reward controls still exist in the game; review them before broader or monetized distribution.

References:
- https://developer.android.com/studio/publish/app-signing
- https://support.google.com/googleplay/android-developer/answer/9845334
- https://support.google.com/googleplay/android-developer/answer/14316361
- https://support.google.com/googleplay/android-developer/answer/6334373

