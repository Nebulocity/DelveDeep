# Known issues and verification needs

- The six stale Node fixtures documented during the October 14 Spell Power merge have been maintained against the authored rank curves, direct equipment bonuses, class-icon footer, Wrath delivery and hidden equipped-sale rows. Full Node validation is now 92/92, including the two new equipment/perk suites. Earlier failure totals are historical. Physical-device balance and readability remain separate verification needs.

- Essence Drain's current catalog describes draining an enemy, but its `Single ally or self` target label sends target selection through the friendly path. Its manaDrain handler acts on the resolved target and does not implement the described caster-missing-Mana drain cap. Umbral VFX preserves those gameplay rules and tracks the resolved target. Resolve the targeting/cap conflict as a separate gameplay task before treating the description as authoritative.

- Slime Cave layer alignment, ambient mask edges and Android video playback need a game/device visual review after the current Blender inspection. This is an integration verification need, not a confirmed rendering defect.
- New class ability values and mobile combat layout need a physical-device balance and readability pass. Provisional tuning is recorded in [Class abilities](CLASS_ABILITIES.md).
- Ability tuning values appear in both `docs/COMBAT_SYSTEM.md` and `docs/CLASS_ABILITIES.md`. Keep those references aligned with `data/classes.js` when balancing.
- Some facilities are placeholders. Their existence is intentional pending future gameplay work.
- The Blender authoring file and source ambient movie are local, not in Git. Back them up separately.
- Character and enemy sprite completion is owned by the active PixelLab chat; check its current handoff before changing those assets.
