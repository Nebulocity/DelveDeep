# Private encrypted save transfers

## Try it locally

Run npm run dev, then select SAVE TRANSFER at the bottom right of the world map.
Transfers are available on the world map, rather than during live combat.
Use a strong backup passphrase of at least 12 characters. This is a separate backup
passphrase, not your Android upload-key password. The game never stores it.

### Export

Enter and repeat your backup passphrase, then choose Export backup. Save the .ddsave file
outside the app. Android presents its system document picker, allowing a location such
as Downloads or an available cloud document provider. Browsers download the file.
Keep the backup and its passphrase; neither the game nor Google can recover a forgotten passphrase.

### Import

1. Enter the passphrase used to encrypt the backup and select Choose backup to restore.
2. Select the .ddsave file. Decryption and structural validation happen before replacement.
3. Review its date, Renown, Gold, adventurer count, cleared Delves and saved-battle indicator.
4. Select Save recovery backup before replacing. The recovery copy contains the progress
   currently on this device and uses the passphrase you entered for this restore.
5. Verify the recovery file was saved/downloaded, check the confirmation box, and select
   Replace progress and reload. Cancelling before confirmation leaves progress intact.

Restore previous progress reads the latest encrypted recovery file retained on this
installation. Enter the passphrase used during that restore. It follows the same preview,
recovery-backup and confirmation flow. Only the latest internal recovery is retained;
the external recovery files remain yours to keep.

## Build for your phone

Use JDK 21 as described in BUILD_AND_DEPLOY.md.

- npm run build:android:private builds a sideloadable debug APK with transfer controls.
- npm run build:android:private:release builds a signed AAB with transfer controls for
  your own internal testers. It requires your existing private upload signing settings.
- npm run build:android and npm run build:android:release use normal production web
  assets and omit the private transfer control.

Both npm run dev and explicit Vite private mode enable the controls. An Android Studio
wizard packages the web assets most recently synced: build:private and cap sync must
precede a private wizard build. The npm helper handles those steps automatically.
Do not distribute the private build on a public track. Public imports will require a
separate server-verified format and progression-validation system.

## Switch from debug to Play without losing progress

1. Install the new private debug APK over your existing same-key debug installation.
2. Export a backup and keep it outside app storage. Test the passphrase and preview first.
3. Once the internal Play build is available, uninstall the debug app only after keeping
   the external backup. The different signing certificates prevent an in-place update.
4. Install the private internal-test build, open SAVE TRANSFER, and restore the backup.

The local recovery file and ordinary saves are deleted on uninstall. An exported file in
Downloads or another user-selected document location survives app uninstall.

## Format and safeguards

The .ddsave envelope is text containing encrypted bytes, not editable gameplay JSON.
AES-256-GCM provides encryption and a 128-bit authentication tag. A random 16-byte salt
and 12-byte IV are generated for each export. PBKDF2-SHA-256 derives the key from the
passphrase with 600,000 iterations. The fixed version-1 format authenticates its identity
as associated data. Changed ciphertext, incorrect passwords, unsupported formats, unsafe
object keys, excessive nesting/size and invalid loader-facing structures are rejected.
Limits are 8 MiB of plaintext and 12 MiB of transfer-file bytes.

Profile and leader records are captured together, including inventory, equipment, world
progress, checkpoints, Everdeep expeditions and any valid active battle. Exact legacy
record bytes are restored, allowing the game's current migrations to run normally.
Active-battle and Everdeep validators reject structurally invalid or unsupported records.

Before replacing either legacy key, the game stores an encrypted recovery file and a
single transaction journal. If either write fails, it rolls back both records. Startup
retries interrupted rollback before loading progress. The journal temporarily contains
the previous local record bytes; local saves were already stored in plaintext. Encryption
protects transfer files, not the underlying localStorage against modified clients.

This is private recovery protection, not proof of earned progression. A player with the
passphrase and modified code can forge another private backup, and restoring an older
save can roll back consumed rewards. No purchase entitlement should be trusted from an
imported local save. No online account, billing, or cloud-save integration is added here.

## Validation

Focused Node checks cover encryption/decryption, fresh randomness, wrong passphrases,
altered ciphertext, plain JSON rejection, invalid profile/leader/battle data, unsafe keys,
quota failure, partial-write rollback and startup recovery. The phone-landscape browser
test exercises real download and file selection, nonmutating preview, replacement and
recovery discovery. Normal production and private web builds and the native Android
debug build pass. The native document picker still needs a physical Pixel review.

The full Node suite exposed two existing failures in replacement-abilities.test.js
(missing GameState in its VM fixture) and selective-travel.test.js (Wrath travel expectation).
The BootScene VM fixture in verdant-tear.test.js was updated for the new recovery hook
and its focused check passes.

References:
- https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/encrypt
- https://developer.android.com/training/data-storage/shared/documents-files
- https://capacitorjs.com/docs/plugins/android
