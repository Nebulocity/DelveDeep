# Quarry, Watch and Abyss balance

Updated 2026-10-13. This extends the actual-combat protocol in THORNBRIAR_BALANCE.md and DOLMARK_BALANCE.md to the remaining Pineshire encounters. Final measured cohorts and reproduction details are recorded below.

## Preparation and supported parties

Supported parties have five members, one tank and one or two healers, with seeded random damage characters. The current roster has three tank classes: Gladiator, Oathwarden and Dawnwarden. Unlike the earlier harness, the regional harness pairs every sampled tank with both healer-count categories. Twelve-party boss cohorts cover all fourteen adventurers; this is still a sample rather than every possible composition.

Quarry progression and farming use departure levels 15/17/20; Watch uses 20/23/25. These fixtures equip the cheapest purchasable class-compatible Common weapons and armor, three free rank-one starters, no purchased tactics and no potions. Actual resources carry through all 23 ordinary waves into the wave-23 farm without a refill. Farm commands periodically use the real Attack, Move and brief Hold handlers.

Prepared Quarry and Watch bosses use levels 20 and 25, respectively, with class-compatible Uncommon equipment, four equipped abilities and all earned SP spent through real training purchases. The cheapest purchasable compatible Uncommon weapon and armor are used, with compatible reward accessories. Barbarian, Ranger and Scoundrel still have no Uncommon armor; their best purchasable Common armor is used. Barbarian has no compatible accessory. This matches the earlier preparation standard rather than silently inventing catalog gear.

Abyss progression starts at level 25 with the best available compatible catalog gear selected for role, one legal catalog enchantment on each equipped item, four equipped abilities and all earned SP spent. Both wave-15 and wave-33 farms use level-26 departures, with cap-level checks at 30. The level-30 boss uses the same fully prepared standard. Armor selection favors physical effective Health plus useful role power; weapon selection favors healing or expected physical/spell damage. These are sensible high-end builds, not proof of a universally optimal equipment combination. Some slots necessarily remain Common or empty where the catalog lacks eligible gear.

Abyss tactics have an explicit conservative progression budget: the starting RP, five shared character milestones through level 25, and five preceding ordinary bosses yield 11 RP and Renown level 11. Normal purchase and five-slot equip rules buy Focus!, Fight On!, Brace!, Encourage! and Ready! for 10 RP, leaving one RP. No Uncommon tactic is affordable from that budget. Unattended runs own these tactics without pressing them. The broad boss comparison uses delayed interrupts plus useful Fight On, Brace and Encourage presses; the maintained regression additionally uses Focus and Ready. Training and equipment are funded preparation fixtures; they do not establish how much Gold or material farming a player needs to obtain the build.

Balanced slot ranks are 4/3/3/1 at level 20, 4/3/3/3 at 25, 4/4/3/2 at 26 and 5/3/3/3 at 30. Specialized builds favor the primary starter and still spend the full legal budget: 5/3/1/1, 6/2/2/1, 6/3/1/1 and 7/2/1/1, respectively. The fourth class skill is learned in the primary starter's category. Each fixture records exact gear, enchantments, skill IDs/ranks, unspent SP and training Gold.

Level 26 is a farm recommendation, not a new entry lock. Fifteen ordinary Abyss clears give only 75 XP and all 33 give 165 XP, while level 25 requires 722 XP to reach 26. A level-25 prepared party therefore needs the early camp to bridge that gap. The maintained regression checks that bridge. Existing lower-level saves and earned checkpoints stay usable.

## Authored enemy changes

| Encounter | Ordinary Health scale | Ordinary power scale | Boss-wave Health scale | Boss-wave power scale |
| --- | ---: | ---: | ---: | ---: |
| Quarry | 0.6 | 0.1 | 0.8 | 0.14 |
| Watch | 1 | 0.2 | 0.85 | 0.28 |
| Abyss | 1 | 0.1 | 1.2 | 2.4 |

Quarry and Abyss ordinary scales remain unchanged. Watch ordinary power falls from 25% to 20% of its catalog totals. Its 25% candidate had zero deaths over 24 hours but reached 19.7% Health in a commanded farm. Matched one-hour reruns of that party at 20% power stayed above 54.3%; a 15% candidate stayed above 73.8%. The selected value keeps more pressure while providing a substantial margin.

The final boss and escorts share their encounter's boss-wave scale. Earlier Abyss guardian boss flags continue using ordinary-wave scaling; they retain their authored entrances and abilities. None of the wave counts, compositions, rewards, floor polygons, reach rules, movement or status behavior changes.

| Final boss | Health | Armor | Attack/Spell Power | Response skill | Potency | Nominal damage |
| --- | ---: | ---: | ---: | --- | ---: | ---: |
| Depths Sovereign | 53,600 | 950 | 70 | Mountain's Wrath | 1,350% physical | 945 |
| Earthsinker | 42,500 | 800 | 105 | Boulder Splash | 1,300% physical | 1,365 |
| Abyssal Sovereign | 100,800 | 0 | 45.6 | Sovereign's Ruin | 2,200% spell | 1,003.2 |

Nominal damage precedes Armor, Block, critical multipliers, shields and other reductions. Each selected finale has an 18-second cooldown and a single six-second warning over a fixed caster-centered 500-unit area. Wrath and Splash retain their warning shape and reach; Ruin expands from 300 to 500 units while retaining its 300-unit cast reach and existing response prompt. Automatic warning avoidance remains disabled for these attacks. Historical active monsters retain their recorded stats and abilities; only fresh spawns receive this tuning. Save IDs, schemas, camps and level caps remain intact.

## Prepared boss results

Each final comparison has 12 supported parties and four combat seeds, with two unattended skill builds and a matched balanced build using 1.5-second response delays. Quarry and Abyss use seeds 11/22/33/44; Watch combines the selected 1,300%-Splash sample at 11/22 with an authored-code confirmation at 33/44. The roster stride is 104729.

| Encounter | Unattended victories | Mean deaths | Assisted victories | Mean deaths |
| --- | ---: | ---: | ---: | ---: |
| Quarry | 15 / 96 (15.6%) | 4.43 | 48 / 48 (100%) | 0.08 |
| Watch | 15 / 96 (15.6%) | 4.39 | 48 / 48 (100%) | 0.10 |
| Abyss | 24 / 96 (25%) | 3.97 | 47 / 48 (97.9%) | 0.35 |

Quarry and Watch intervention answers only their selected finale. Abyss answers the ground warnings for Collapse and Ruin and uses the affordable tactics described above; the targeted Soul Rend cast still resolves, so this is a limited response policy rather than perfect cancellation of every boss action. Assisted results exceed the provisional 70-85% target. The intended preparation and response are highly effective in these samples, while unattended encounters commonly wipe. These figures do not establish success for every party or for unprepared play.

## Actual farming and XP

| Encounter | Farm hours | Repeat clears | Lowest HP | Mean cycle |
| --- | ---: | ---: | ---: | ---: |
| The Old Quarry | 24 | 1,231 | 57.1% | 69.4 sec |
| The Sunken Watch | 24 | 1,972 | 54.3% | 43.6 sec |
| The Murmuring Abyss | 48 | 3,333 | 71.2% | 51.5 sec |

The final endurance cohorts contain 24 Quarry hours, 24 Watch hours and 48 Abyss hours, using six supported parties, two combat seeds and both unattended/commanded farming. Abyss splits those hours evenly between camps 15 and 33, and includes twelve separate level-25 full-progression sequences. Across endurance and maintained regression, 300 supported sequences reached their requested camps without deaths. All fourteen current adventurers appear in each encounter's combined fixtures.

The Old Quarry: 72 progression sequences; mean farm fight 61.4 seconds and full cycle 69.4 seconds. Individual fixture cycle means range from 54.7 to 84.3 seconds. 

The Sunken Watch: 72 progression sequences; mean farm fight 36.1 seconds and full cycle 43.6 seconds. Individual fixture cycle means range from 34.2 to 54.4 seconds. 

The Murmuring Abyss: 156 progression sequences; mean farm fight 43.5 seconds and full cycle 51.5 seconds. Individual fixture cycle means range from 32.9 to 85.4 seconds. Camp 15: 24 hours, 1914 repeats, 81.1% Health low and 44.9-second mean cycle. Camp 33: 24 hours, 1419 repeats, 71.2% Health low and 60.4-second mean cycle.

Separate missing-role stress cases run the same progression plus ten minutes of farming when a camp is reached. These runs are excluded from supported-party percentages.

The Old Quarry stress: no-tank 4/4 reached camp, 0 defeats, 0 deaths and 50.0% overall Health low; no-healer 3/4 reached camp, 4 defeats, 20 deaths and 0.0% overall Health low.

The Sunken Watch stress: no-tank 4/4 reached camp, 0 defeats, 0 deaths and 29.0% overall Health low; no-healer 0/4 reached camp, 4 defeats, 20 deaths and 0.0% overall Health low.

The Murmuring Abyss stress: no-tank 8/8 reached camp, 0 defeats, 0 deaths and 78.3% overall Health low; no-healer 8/8 reached camp, 0 defeats, 0 deaths and 18.9% overall Health low.

No finite test establishes death-free farming for every party or input pattern. These claims cover the recorded preparations and ordinary command policy, with actual damage and unfinished-fight Health minima included. Missing-role parties remain outside the supported survival target; ten-minute stress survival alone does not establish dependable long-term farming. The existing 2,021 / 3,114 / 4,518 XP bands and provisional 32 / 32 / 64-hour targets remain unchanged. Progression XP and both Abyss camps are included in the measurements. Combat stats and equipped ranks remain the departure build even if roster XP later levels a character; midpoint and cap visits are separate fixtures.

## Validation and reproduction

The maintained browser files are tests/visual/regionalDelveSimulation.js, regional-delve-simulation.spec.js and regional-delve-response.spec.js. They use the actual Phaser combat AI, movement, damage, recovery, timers and reward code through 50 ms replay steps. Death-free estimated offline farming is excluded. Each fixture resets owned gear, roster, leader, scene clock and seeds; rendering/background progress and persistent combat-log writes are suppressed inside isolated QA contexts.

Run npm run test:visual -- regional-delve-simulation.spec.js --workers=1 for the three maintained balance checks, and regional-delve-response.spec.js for advice, pause, fixed centers, canceled delayed damage and exact repeated-scene seeded equality. The focused Node check is tests/regional-delve-balance.test.js, alongside the maintained Abyss cast, preparation, checkpoint and save-migration checks.

The response checks pass at 915x412, with preparation screenshots inspected. The final production build passes with this environment's existing preserve-symlinks configuration; a normal build attempt encountered the already documented main.js realpath EPERM. The ignored file-delivery adapter runs the maintained assertions without localhost access. The Node suite is 85/88, with the three existing failures in replacement-abilities (missing GameState fixture), selective-travel (obsolete Wrath expectation) and shop-services (equipped-item sale-row expectation). Physical Pixel 9 review remains pending.

Raw reports, screenshots, adapters, candidate experiments and review output stay ignored under output/qa/regional-simulation/ and .tmp/. Finished game code needs no generation service or API keys.
