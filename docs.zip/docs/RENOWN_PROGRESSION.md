# Renown progression

Implemented 2026-10-12. This economy is intended for fresh data; existing local balances and tactic unlocks remain readable, but old achievement history is not reconstructed. No automatic reset occurs.

The player is the Party Leader, separate from adventurer combat levels. Renown Level is earned standing; Renown Points (RP) are spendable leadership currency. Spending never lowers Renown Level. Five tactics can be equipped.

## Rewards and caps

- Start at Renown Level 1 with 1 RP and no unlocked tactics. Focus Fire costs 1 RP; the player chooses and equips it in town.
- The first adventurer to cross each character-level multiple of five grants +1 Renown Level and +1 RP. Claims are global to the roster, not per character. Large offline gains process each crossed milestone.
- First completion of each ordinary Delve grants +1 Renown Level and +1 RP for its final boss. Intermediate guardian waves do not pay. Stable world IDs identify claims, not reused enemy or environment types.
- Each distinct Void Portal closure grants +1 Renown Level and +1 RP, once. Its boss does not also award a Delve boss point. Replaying the same portal does not create a new closure.
- Pineshire totals 13 levels/earned points: starting 1, six character milestones through level 30, five ordinary Delve bosses, one portal closure.
- Character and Renown caps are 50 in config/renown.js. Character XP and direct level grants stop at 50; lower Delve caps still apply. Gold and Happiness eligibility respect the lower cap; materials remain available. Existing higher-level local characters retain their data but cannot advance further.
- New unclaimed achievements still grant RP when Renown Level is capped. Dev Tools grants only pay points for actual Renown levels gained.
- Retreat never deducts RP. Ordinary banked rewards and portal encounter loss rules remain unchanged.

## Rarity gates and provisional prices

| Rarity | Renown required | Acquisition |
| --- | ---: | --- |
| Common | 1 | 1-5 RP |
| Uncommon | 10 | 15-20 RP |
| Rare | 20 | 30-35 RP |
| Epic | 40 | 45-50 RP |
| Legendary | 50 | Future quest chain, never a shop purchase |

Existing catalog assignments are provisional tuning choices, not simulated balance results:

| Tactic | Rarity | RP |
| --- | --- | ---: |
| Focus! | Common | 1 |
| Fight On! | Common | 2 |
| Brace! | Common | 2 |
| Encourage! | Common | 2 |
| Ready! | Common | 3 |
| Revive! | Common | 3 |
| Shield Wall! | Common | 4 |
| Regen! | Common | 4 |
| Supplies! | Common | 5 |
| Coordinated Attack! | Uncommon | 15 |
| Lunar Assault! | Uncommon | 18 |
| Mana Vortex! | Uncommon | 20 |
| Arise! | Rare | 35 |

Purchase validation checks both standing and RP in game/LeaderProgression.js. Locked tactic cards remain visible with rarity, level requirement and price; tapping or holding explains their effects. No Epic or Legendary tactics have been invented for this update.

## Agreed future direction, not implemented

Premium currency may come from real-money packs or optional daily rewarded ads. It may buy additional RP without buying Renown Level or bypassing rarity gates. Pineshire's candidate allowance is seven extra RP total, shared by ads and money; spending must never reset the allowance. This is a lifetime acquisition allowance, not a wallet cap. Later allowances and premium currency prices are still undefined. Earned RP must not be discarded because of a premium allowance.

Legendary tactics require earned Renown 50 and a substantial quest chain. Quest rewards may supply RP independently of Renown Level. Future regions may raise both global caps and add horizontal build progression. Party shields and enemy-pull tactics remain examples awaiting authored behavior and balance. Refunds/respecs are a consideration, not an implemented feature.

## Validation

Focused Renown, XP-cap, development, checkpoint and offline-farm checks pass. The full Node suite passed 82/84 checks; replacement-abilities.test.js and selective-travel.test.js retain the previously documented unrelated failures. Renown purchase, equip, locked-detail, gate and reload browser checks pass at 915x412 and 1920x1080. Production build passes with the host filesystem access Vite requires. Visual review used isolated output and a temporary watcher-free server because other active chats were editing shared files. Physical Android review remains pending.

