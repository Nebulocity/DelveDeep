# Thornbriar balance pilot

Updated 2026-10-13. This pilot covers Thornbriar only. Subsequent encounter passes are documented in DOLMARK_BALANCE.md and REGIONAL_BALANCE.md.

## Intended experience

Ordinary progression should reach camp with minimal intervention for varied five-member parties containing one tank and one or two healers. Repeated farming should have a comfortable survival margin in actual combat, including ordinary Attack, Move and brief Hold commands. Missing-role parties are stress cases, reported separately.

Rongar should be very difficult unattended at level 10 with appropriate Uncommon gear, four equipped skills and all ten earned SP spent. Good RNG or a strong composition can still win. Responding to his dangerous cast should substantially improve success.

## Authored changes

| Ordinary enemy | Health | Armor | Attack Power | Spell Damage |
| --- | ---: | ---: | ---: | ---: |
| Ruffian | 1,680 | 96 | 3 | 3 |
| Lasher | 2,800 | 144 | 3 | 3 |
| Hedge Mage | 2,240 | 144 | 3 | 3 |

These encounter-local totals are 70% of the previous ordinary Health and 50% of its power. Ordinary percentage skills, wave counts, compositions and rewards are retained. Catalog totals and boss escorts still use their existing definitions and preparation scales.

Belch has one 4.5-second warning, a fixed caster-centered radius of 400 logical arena units, 900% Spell Damage potency, a ten-second cooldown and its existing three-second stun. Rongar's Thornbriar power scale remains 0.23, giving about 569 nominal pre-defense damage from Belch before critical multipliers. Allies do not automatically dodge this player-response warning. The player can interrupt it or move outside its fixed area. Other Rongar abilities retain their existing values and automatic avoidance.

The preparation profile now specifies level 10, compatible Uncommon gear, all four equipped slots and SP spent on ranking those skills. The tooltip reads the profile rather than hard-coding Common gear. The level cap, checkpoint IDs, wave-nine farming, rewards and existing saves remain compatible. Saved active monsters retain their recorded stats and abilities; fresh spawns receive current definitions.

## Simulation protocol

The maintained browser harness is `tests/visual/thornbriarSimulation.js`, invoked by `thornbriar-simulation.spec.js`. It advances the real combat clock, AI, movement, abilities, resource costs, threat, drops, recovery and rewards in the existing 50 ms combat-replay steps. It does not use estimated offline farming, which deliberately cannot create new deaths.

Every fixture resets the scene clock, equipment ownership and roster, seeds initialization and combat RNG, and suppresses purchased tactics and potion use. Repeated-scene equality is checked separately in `thornbriar-response.spec.js`. The Phaser game loop and background timer are stopped inside isolated Playwright contexts, so wall time cannot add combat between fixtures.

Progression/farm fixtures use level 5, 7 or 10, cheapest purchasable compatible Common weapons and armor, and the three free rank-one starters. All nine ordinary waves carry their actual resources forward. Farming starts from that camp without a refill. The current game keeps departure combat stats until a later visit, even if farm XP levels the roster; testing several departure levels covers that distinction.

Boss fixtures start at level 10 with full resources and the real readiness reset. They use the cheapest purchasable compatible Uncommon weapons and armor, plus compatible Uncommon accessories. Ranger, Scoundrel and Barbarian have no Uncommon armor, so they use their best purchasable Common armor. Barbarians have no compatible accessory; the catalog contains no Common accessories. Accessory grants are preparation fixtures, not proof that those reward items are affordable or available from shops.

Training uses real purchases and level gates with a funded test Gold balance. Both builds spend all ten SP legally after learning a fourth class ability in the primary category. Balanced builds rank the primary starter to three, secondary starter and fourth class skill to two, and generic starter to one. Specialized builds rank the primary starter to three, secondary and generic starters to two, and fourth class skill to one. Each fixture records owned gear, equipped skill IDs/ranks, training Gold and unspent SP.

Simple boss intervention uses the real Interrupt tap handler only for Belch, after a 1.5-second reaction delay. It does not interrupt other warnings, use tactics or spend potions. Farm input periodically issues Attack, moves an injured ally toward the party and briefly Holds, releasing those orders after two combat seconds. Deliberately remaining in lethal boss warnings is outside the farm safety target.

## Measurements and limits

The one-hour entry-level endurance cohort used twelve supported parties, two seeds, and both unattended and commanded farming: 48 full simulated farm hours, 4,164 repeated clears, zero deaths, and a worst measured Health low of 45.1%. All 48 progression sequences reached camp without deaths. Mean farm fight duration was 33.3 seconds; the full cycle including return/rest/countdown averaged 41.3 seconds. The no-tank stress party also survived; no-healer parties eventually wiped.

The authored regression separately covers every one of the fourteen adventurers in six varied parties at departure levels 5/7/10. Its 48 supported progression/farm fixtures reached camp without deaths and cleared 797 repeat fights without deaths. Unattended full-cycle means were 36.1/34.4/32.6 seconds by departure level. The original ungeared Garrick/Durgrim/Zahra/Orwen/Sylva test separately passed twelve one-hour trials without deaths; its damage-heavy lineup averages about twenty-second fights. Its old strict twenty-second minimum was replaced with a fifteen-second floor while retaining the survival and Health-margin assertions.

Earlier boss sweeps are exploratory and superseded by the fully-spent-SP cohorts. Their evenly ranked build left one SP unspent; do not quote them as the final fully prepared boss benchmark. Final native 900%-Belch cohorts include 192 unattended fights and 96 matched balanced-build fights with simple Belch intervention. Every hero has four equipped skills and zero unspent SP.

| Final boss condition | Victories | Win rate | Mean character deaths |
| --- | ---: | ---: | ---: |
| Unattended, both rank builds | 42 / 192 | 21.9% | 4.04 |
| Belch interrupts after 1.5 seconds | 85 / 96 | 88.5% | 0.78 |

Unattended one-healer parties won 25/96 and two-healer parties won 17/96; composition and damage output matter more than simply adding healing. The commanded trials averaged 3.08 Interrupt taps per boss fight. Both cohorts pass outcome assertions, including meaningful intervention benefit and zero unspent SP.

No finite set of runs proves farming can never cause a death. The zero-death result applies to the tested preparations, parties and command policy. Boss success varies strongly with composition; low-damage mage-heavy parties are particularly vulnerable to long fights. Phone-size browser advice, pause, warning-center retention and interrupted delayed damage are tested; physical Pixel 9 review remains pending.

The XP curve is unchanged. Thornbriar still budgets 640 XP across levels 5-10 against a provisional 45-second cycle and eight-hour target. Cohort means suggest roughly six to seven hours after normal wave XP, but individual entry-level unattended parties averaged 28.4-78.1 seconds per full cycle. Holding those departure stats constant implies approximately five to thirteen-and-a-half hours across compositions. Training, gear, future departure refreshes and offline return staging can change the pace further. Revisit XP/economy and class damage throughput after the remaining Delves receive the same balance pass rather than changing a shared curve from one encounter alone.

## Reproduction

Run `npm run test:visual -- thornbriar-simulation.spec.js --workers=1` for the maintained regression and `npm run test:visual -- thornbriar-response.spec.js --workers=1` for advice, interrupt/pause behavior and seeded repeatability. The original starter check is `thornbriar-balance.spec.js`.

Exploration accepts a JSON `DELVE_SIM_OPTIONS` with `parties`, `partySeedStride`, `seeds`, `farmMs`, `stress`, `candidates` and `scenarios`. `DELVE_SIM_LABEL` names the ignored report. `DELVE_SIM_VALIDATE=1` applies the balance outcome assertions to custom cohorts. Use distinct Playwright `--output` directories and ports for concurrent processes so trace cleanup cannot collide.

Raw measurements and screenshots remain ignored under `output/qa/thornbriar-simulation/`. Long endurance uses `farmMs: 3600000`; ordinary regression uses 600000. The two final boss cohorts use twelve parties each, stride/seeds 1/[1,2,3,4] and 104729/[11,22,33,44], both rank builds and simple Belch intervention. Before applying the chosen ordinary totals, its endurance candidate used `normalHealth: 0.7, normalPower: 0.5`; the authored configuration now has those totals directly, so use an empty tuning object when reproducing it.

Required production build and focused Node checks pass. The broader Node suite is 81/84, with unchanged HUD fixture, Wrath delivery expectation and equipped-shop-sale expectation failures. These are outside the Thornbriar balance changes.
