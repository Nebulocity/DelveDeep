# Delve Deep – UI / UX Rules

## General

- Landscape-only interface.
- Designed primarily for Android phone use.
- UI should remain readable on a Google Pixel 9-sized display.
- All game text has intentionally been increased substantially from the original scale.
- Do not reintroduce tiny fonts.
- All runtime font sizes, families and weights live in `config/uiTypography.js`. Generic scale slots cover common text; named Hall, shop, map, preparation and battle slots let phone readability be tuned per use. Sizes are logical canvas pixels before display scaling. The Hall equipment cards use a View Stat Bonuses popup, tactics use held details, and the map destination rail scrolls for larger labels.
- Touch targets should be large enough for fingers.
- Haptic feedback should be preserved on appropriate interactions.
- Town guidance, tooltips, confirmations and feedback use the supplied Pineshire wooden details plaque. Shop held details use readable message boxes matching their facility action plates: herbal green and brass for the Alchemist, iron and copper for the Blacksmith, and violet with arcane trim for the Enchanter. The region map uses textured forest-green surfaces with bronze edging and contour-line ornament for its banner, destination rail, map labels, controls, notices, held details, How to Play, Dev Tools and reset confirmation. Do not use wooden plaques or flat colored visible panels on the region map. Center travel, lock, road and location-detail messages within the map viewport; center UI feedback, help, Dev Tools and confirmations within the full game screen. Battle controls, announcements, held details, camp and results use the approved Carved Stone delve interface. Size panels around readable text and keep controls inside them.

## Delve Interface

- Delve Overview, Party Select and Battle Overview inherit the selected environment's Carved Stone panels, trim, ivory text and gold selection borders. Their navigation, instructions, held details and limit feedback use stone instead of town wood. Show the authored environment behind the preparation workspace; preserve preview aspect ratio.
- Party Select retains four scrollable role lists with sprite portraits and a five-slot selected lineup. Tap a lineup member to remove them, or hold for gear-adjusted stats. Masks constrain both rendering and hit tests. Keep five-member and role limits, empty first selection and saved party restoration.

- Use dark slate panels, dull iron edging, ivory labels and gold selection borders from the approved Carved Stone concept. Keep role choices on the left, orders and retreat on the right, and five party cards below the authored walkable arena.
- The title and wave/checkpoint status share a flush top banner with Pause/Resume. Leadership tactics and equipped potion controls remain available.
- Wave rewards use floating battlefield text with actual Gold, XP and named drops on separate lines. Keep rewards visible during the return to formation and for three seconds after the party settles at its starting positions.
- Center the equipped tactics row beneath the delve title for any loadout of up to five tactics. Keep battle guidance below the tactics controls.
- Ordinary camp presents three large horizontal choices: Leave Delve, Farm the final pre-boss wave, and Face the Boss. Leave Delve opens the world map at the current location with banked rewards and checkpoints saved. The farm description reads "Gold, XP, Happiness, and Materials"; the boss description reads "Challenge the boss of this Delve to earn better rewards and unlock the next Delve!". Once that Delve is recorded as cleared, dim and disable Face the Boss and show "Boss already defeated"; leaving and farming remain available. Void encounters keep their separate flow.
- Enclose the Delve Camp heading and saved-checkpoint message in their own Carved Stone window above the action tiles.
- Farm repeats the final pre-boss wave until Cancel Farm is requested. The cancel control appears below the role rail and queues a return to camp after the current wave clears and pays its rewards. Its pending label remains visible; cancellation never skips enemies or resets combat resources.
- Delve trim varies by environment: slime and violet crystals, roots and amber accents, water and moss tones, or violet runes. Controls retain consistent positions.
- Button faces ease down over 90 ms, stay down while held, and ease up over 140 ms. Touch targets remain fixed. Activate on release; leaving the target, leaving the game or losing focus cancels the press. Existing 550 ms held details suppress the normal action.

## Top Banner

- The top banner should sit flush with the top of the game area.
- Avoid leaving an unnecessary visible gap above it.
- Respect Android safe areas / system UI as needed.

## Text

- Text should wrap inside panels. Delve detail body text and drop bullets are left-aligned within their text column, with the title centered above that column. Other selection details remain centered unless their layout requires left alignment.
- Instructional text must not overflow outside windows.
- Developer/testing warnings should wrap cleanly.
- Avoid clipping or placing labels partially off-screen.

## Character / Party UI

### Battlefield Characters

- Do not place the class label over the battlefield character.
- Do not place a mana bar above the battlefield character.
- Show each battlefield health bar above its character or monster sprite, with the name above the bar.
- Place cast bars 1px below battlefield health bars, clear of the sprites.
- Use continuous range shapes for character abilities. Keep enemy area warnings visible.
- Keep character health information in the bottom party card as well.

### Bottom Party List

Each party member should show:

- Name.
- Class on a line below the name.
- Health bar.
- Mana bar when applicable.

Mana belongs in the bottom character / party UI, not floating over characters on the battlefield.

Portrait cards follow the left-to-right starting battlefield formation. Keep that order stable while adventurers move during combat.

## Character Selection

- Adventurer cards must remain fully on-screen.
- No newly-added adventurer card should appear partially off-screen in the upper-left or elsewhere.
- Character selection sections may scroll when needed.
- First-time Party Select should begin empty.
- Later Party Select screens should default to the previously used party.

## Selection Behavior

- Informational selections support a 550 ms long-press or mouse hold-click.
- Show an instruction on each screen with inspectable selections.
- A hold opens details without also performing the normal tap action.
- Dragging away, releasing, leaving the game, or changing scenes cancels a pending hold.
- Details and confirmation popups block underlying controls without pausing gameplay or clocks. Wave countdowns, cooldowns, casts and other timers continue while popups are open. Use the battle Pause button to explicitly pause combat; opening or dismissing a popup preserves that manual pause.

- Tapping a unit with no active selection selects it. Selected living units show gold borders around their bottom cards only, with no gold outline around portraits or battlefield sprites; role categories highlight their selected members.
- Tapping the only selected unit again deselects it. With an existing selection, tapping another ally through its battlefield sprite or bottom card commands the selected allies toward that target and clears selection after issuing the order. Enemy-targeted orders also clear selection. Group members can also be targets; the clicked member anchors at its current position. Healers prioritize the injured target, including themselves when they are the group anchor. Tap the selected role category again to deselect a group.
- Tapping arbitrary battlefield space should not automatically cause the entire party to move unless that is the active command.
- The bottom status card for each party member is a generous individual
  selection target: tapping its portrait, name, or class selects that member.

## World Map

- Location icons should appear below location nameplates.
- Avoid overlapping map icons with labels.
- Remove obsolete descriptive labels such as the old road text if present.
- Keep location names readable against the background.
- Preserve the pixel-art visual direction.

## Town Menu

- Facility choices use distinct hanging wooden signs with large labels and touch targets.
- Each facility menu uses large, themed action cards with icons and a palette that reflects the room.
- Shop list guidance sits inside the list header, clear of the scrollable two-column item grid and compact facility action cards. Keep the category rail beside the grid; touch drag, mouse wheel and the themed scrollbar browse all items without paging. Return to Town is the shop exit, without an extra list close button. Facility action cards show an icon and label, with descriptions available by holding them. The unopened facility menu places guidance above its action cards.
- A brief tap swings the selected sign before navigation. A hold opens a matching wooden details plaque without navigating.
- Keep descriptions in the details plaque instead of on the signs.
- The World Map sign hangs below the facilities from the same beam, with chains routed through the center gap. Place the hold hint at the bottom of the town screen.

## Adventurer's Hall

- Enter directly into the Adventurers workspace. Keep Adventurers, Items, and Tactics navigation visible across all Hall sections, with Town as the return destination.
- Use tiled oak grain, leather insets, brass corner fittings, guild crest medallions, ivory text, and the supplied Hall interior. Skin every control, including Town, navigation tabs, roster cards, gear slots, scrollbars, skill actions, paging, and popup buttons. Reserve brighter brass for selection and affordable training actions.
- Hall held details and purchase confirmations use framed parchment guild ledgers with clear header/body/button regions. Character inspection separates the portrait, stats, and a two-column Known Skills list with learned ranks. Skill held details show target type and current rank/equipment damage or healing ranges; these are base values before critical hits, temporary buffs and target mitigation. Keep text inside the paper inset, clear of decorative trim. Equipment and full-stat popups use the same oak/leather/brass materials. Hall popup styling is scoped to Hall scenes; town, shops, region-map, and combat popup themes retain their own styles.
- Group the roster as Tanks, Healers, Melee DPS, and Ranged DPS with distinct colored emblems, headings, member counts, and vertical markers. Portraits, names, and class labels remain readable; masked list controls reject taps outside the visible list.
- Keep the selected character and gear-adjusted summary beside focused Equipment and Abilities tabs in the same navigation row as Adventurers, Items and Tactics. Preserve character selection, the active tab, and list position when returning from Items or Tactics. Group the full character stats into Progress, Attributes, Defense and Offense, preserving held explanations for every field.
- Equipment cards have a compact View Stats button and an Equip button beside it. Enchanted items show a glowing purple scroll in the slot's upper-right corner, and the same marker appears left of the item name in every stats view. Weapon and armor pickers omit Unequip because those slots always stay filled; accessory and potion slots can still be emptied. Held equipment and item details show the catalog description, compatible classes, minimum level and owned bonuses with attribute conversions in parentheses. Equipment pickers show only compatible, level-eligible, owned, unequipped copies. Picker rows show stat bonuses and equip immediately on tapping Equip, close the picker and return to Equipment; use the existing inventory and save rules, including potion compatibility and charges.
- Shop lists sort items by rarity from highest to lowest, then by name from A to Z. Equipped items never appear in sell lists. In the Enchanter, selecting a scroll exposes a Back to Scrolls control so the player can cancel before choosing gear.
- Keep four battle ability slots visible above the scrolling skill book. Equipping is separate from confirmed learning/training, with actual level requirements, skill point costs, and happiness-adjusted Gold prices.
- Keep Items categories and pages touch-sized, hide zero-count owned materials, and retain enchantment scrolls. Tactics shows Renown Level, Renown Points (RP), rarity, level gates and prices, and a maximum of five equipped tactics. Level-locked tactics keep readable effect descriptions and active held details while their surfaces are dimmed.
- Keep the title banner flush with the usable game area; CSS owns device safe-area insets. Controls activate on release, cancel after dragging or losing focus, and retain held details and haptics.

## Persistent Messages

Instructional / action-required messages should remain visible until the player has completed the relevant action.

Do not automatically dismiss important guidance purely on a short timer.

## Dev Tools

Developer/testing UI should:

- Fit inside its panel.
- Be directly accessible from the world map in production builds. Tools visibility does not imply unlock-all or replay mode.
- Wrap explanatory text.
- Clearly distinguish destructive actions.
- Support progress clearing.
- Support unlock-all / testing mode behavior.
- Arrange controls in labeled rows for Dev mode, Renown Level (+1/+5), Character Level (+1/+5 for the entire roster), Gold (+1,000/+5,000), Arena Border (on/off), and progress reset, with a separate Close button.
- Never shade the battlefield floor. Hide the battlefield border with the grid lines while keeping tile interaction active. Save the grid preference with the profile and show grid lines for older saves without that preference.
- Replace the previous Dev Tools feedback toast when another action is tapped before it fades.


