# Delve Deep - World Map

## Runtime: illustrated Pineshire Reach

The game uses `assets/world-map/illustrated-regions-v1/01-pineshire-reach-v4.png`, with the southern village dead end removed. The former tile world, map editor, prior map editions and review page are archived in ignored `project-backup/`. The movement manifest records their locations; the selected regional illustrations remain active.

`data/worldMap.js` exports the illustrated runtime graph from `data/illustratedWorldMap.js`. Normalized image positions define destinations, label positions, a separate branch lock, and the future region exit. The image occupies a 3840-by-2160 logical map. Each road stores a manually traced polyline; routing weights, movement, direction, rerouting, and reload/resume all use its arc length. Do not use the straight lines in the artwork review page as party routes.

Pineshire has exactly eight destinations: one Town, five ordinary Delves, one Everdeep entrance, and one Void Portal. The main route is Pineshire, The Slime Cave, Thornbriar Hollow, Dolmark Den, The Old Quarry, and The Sunken Watch. Each Delve boss opens the road to the next. The Sunken Watch boss removes the independent lock marker and opens the Y-branch to both the Everdeep and The Murmuring Abyss. The portal boss opens the outgoing road sign toward Highmere Crags. Highmere is not playable in this first-region integration; the sign explains that limitation.

The Slime Cave, Thornbriar Hollow, Dolmark Den, and Murmuring Abyss use their authored encounters. Old Quarry uses Quarry Worm, Quarry Behemoth, Quarry Reaver and Depths Sovereign in six waves inside its own underground quarry chamber, with an independent floor, masked foreground rubble, flickering lanterns and pulsing teal crystals. Sunken Watch has its own six-wave roster: Sunken Watcher, The Deep Tongue, Drowned Knell, and The Earthsinker boss. Its dedicated flooded lower watchtower chamber has its own floor polygon, foreground masonry, lantern flicker and water ripples. It retains the inherited difficulty and material pool, independent clears and checkpoints. Reused combat inherits its template environment's authored walkable polygon and uses continuous positions and distance-based reach.

## Saves and stable IDs

Existing IDs are retained for the original three Delves, Pineshire, Everdeep, and Murmuring Abyss. Old Quarry retains `march-west-delves`; Sunken Watch retains `verge-delves`. These map to the package's Delve 4 and 5, rather than replacing established save identifiers with the review page's proposed IDs. Existing character growth, gold, inventory, records and checkpoints remain intact when the profile loader adapts an old world layout. Retired current locations return to Pineshire; old-layout travel is discarded rather than interpreted as a new road. Profiles mark the new world layout as `illustrated-pineshire-v1`. The established fresh-progress-per-production-build rule still applies.

Sunken Watch's authored template is `sunken-watch`. Its retained `verge-delves` map ID resolves through `getDelveById` for battle resume, and overrides the former Thornbriar encounter ID in older saved definitions. Existing bandit keys remain available to restore live enemies in an older snapshot. New monster stats are provisional inherited attack profiles; special abilities await the supplied list.

## Interaction and presentation

While standing at The Sunken Watch (`verge-delves`), the Pineshire rail entry reads "Waystone · Instant return". Tapping it returns immediately to Pineshire and opens Town. This return-only shortcut does not add a road, bypass outward boss gates, or interrupt a trip already in progress. Settings replaces Dev Tools in all runtimes; encrypted Save Transfer is temporarily visible in every build.

Drag from terrain, a landmark or its nameplate to pan; tap to travel and hold for details. Movement beyond 24 logical pixels cancels taps and holds. Fixed controls and modal dialogs block map drag. Names sit above landmarks, with status icons beneath. The party follows the painted roads and stops at destination clearings. A fixed left destination rail lists all eight regional locations without covering the map viewport. Locked locations are dimmed; cleared locations and the current or traveling destination have distinct status text. Tap an accessible row to travel directly along the existing traced roads, passing intermediate locations without opening them; hold a row for details. The map camera uses 0.70 zoom inside a separate viewport below the flush header and above the footer. Find Party pans for 750 ms toward the moving party, then resumes smooth follow with the party lower in view. Starting travel uses the same pan, and dragging cancels it. A separate full-screen UI camera keeps controls, notices and dialogs at their normal readable size. All map surfaces share a textured forest-green finish, bronze edging and contour-line ornament, including landmark labels, controls, notices, held details, How to Play, Dev Tools and reset confirmation. Wooden plaques remain exclusive to town flows. Touch targets, haptics and visible production Dev Tools remain available. Reset progress requires a fresh confirmation press/release. The top banner is flush with the usable game area. Camp exits choose reachable Pineshire, and revisits reopen saved camps.

## Animated scenery

The Pineshire illustration has localized cosmetic overlays authored in
`data/worldMapAmbience.js` and drawn by `ui/WorldMapAmbience.js`. Reference coordinates
use a 1672 by 941 view, scaled to the 3840 by 2160 logical map. One noninteractive
Graphics layer redraws at 24 FPS below the party and labels, with map-camera filtering
and scene-shutdown cleanup. Smoke, firelight/embers, slime, eye glow, Everdeep lights,
Abyss energy/floating stones and downstream water highlights supplement the original
painted artwork. Water paths are split around bridges. Saves and travel are unaffected.
This is a first overlay pass; replacement patches and physical Android review remain
possible follow-up work.

## Remaining regions

The manifest selects Pineshire v4, Reedhaven v2 and seven v3 backgrounds. These are separate illustrations, not a seamless atlas. Regions 2-9 still need individually traced roads, encounters, region transitions and saved travel. Each uses the same five-Delve/Y-branch contract. Tidewatch's lower cave and upper mine are one Delve: its boss unlocks the upper exit, while retreat/defeat returns to the lower mouth. Preserve that contract when integrating the coast. See the art package README for archived prompt locations and cleanup decisions.

Validation: `node tests/world-map.test.js`, `node tests/world-map-demo.test.js`, `node tests/delve-checkpoints.test.js`, `npx playwright test -c tests/visual/playwright.config.js illustrated-map.spec.js scenes.spec.js`, and `npm run build`. Phone-sized browser checks supplement physical Android review.
