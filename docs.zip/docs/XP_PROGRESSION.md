# Adventurer XP plan

Every adventurer uses the same level-1 through level-50 curve in config/adventurerXp.js. XP is saved as progress toward the next level. The current global character level cap is 50, configurable in config/renown.js. XP gains clip at the lower of this global cap and the Delve cap; direct development grants stop at 50 too. The older linear XP fallback remains readable for historical data but cannot advance a capped character. Existing higher-level local saves retain their stats and banked XP but cannot gain further levels. The starting-level bands reset their per-level costs to match the encounter's estimated clear speed.

Normal pre-boss waves award 1/2/3/4/5/6 XP and Gold by difficulty. Farm waves award exactly one XP per surviving uncapped adventurer. The hours below are approximate farming budgets for each band, not cumulative hours or strict timers. They double by difficulty: 4, 8, 16, 32, 64, 128. Quarry and Watch both target 32 hours. Normal wave XP reduces the farm time slightly. Gear, trained skills, party choice, casualties, camp choices and departure-stat refreshes can change clear speed.

Cycle estimates include the measured prepared-party fight plus return/rest/countdown allowance. The Thornbriar pilot measures a 41.3-second mean full cycle in its level-5 endurance cohort and 36.1/34.4/32.6 seconds in a faster cohort at departure levels 5/7/10. Cohort means imply roughly six to seven hours after ordinary wave XP, but individual entry-level parties averaged 28.4-78.1 seconds per cycle: about five to thirteen-and-a-half hours if departure stats remain constant. The unchanged 640-XP band and eight-hour target remain provisional pending regional balance, economy and class-throughput review. See THORNBRIAR_BALANCE.md. Dolmark now measures a 35.7-second full-cycle mean across 48 entry-level farm hours, with individual party means of 26.4-52.9 seconds. Its unchanged 1,694-XP band minus 45 ordinary-wave XP implies about 16.4 farming hours at the mean, or roughly 12.1-24.2 hours across those compositions while holding departure stats constant. The midpoint/cap regression is faster at 31.3/29.8 seconds per cycle. See DOLMARK_BALANCE.md. Levels 30-50 are fully planned but provisional until later-region encounters are authored, using Impossible's 128-hour budget per five levels. Pineshire camps use the ending level as the XP cap. Higher-level adventurers can help lower-level party members but earn no XP or Happiness themselves; Gold is reduced by their capped fraction, rounded upward. Fully capped parties earn materials only. Selling materials for Gold still supports equipment, ability training and crafting. New XP cannot overflow a Delve cap. Existing saved XP, levels, gear and skills remain intact.

The regional pass measures Quarry at 69.4 seconds per full cycle and Watch at 43.6, across 24 supported entry-level farm hours each. After 92 ordinary-wave XP, their unchanged bands leave 1,929 / 3,022 farm XP, implying approximately 37.2 / 36.6 farm hours while holding departure stats constant. Individual fixture cycle means span 54.7-84.3 seconds for Quarry and 34.2-54.4 for Watch; departure refreshes at midpoint/cap are faster. Fully prepared level-26 Abyss farming measures 44.9 seconds at camp 15 and 60.4 at camp 33, with 24 hours at each. Both camps currently use the same fixed difficulty rewards, so the earlier camp is more efficient in these preparations. Revisit the two-camp economy, gear/training affordability and class throughput in a separate shared-economy pass. The 2,021 / 3,114 / 4,518 XP bands and 32 / 32 / 64-hour provisional targets are unchanged. See REGIONAL_BALANCE.md.

| Level band | Difficulty | Farm hours | Cycle seconds | Band XP |
| --- | --- | ---: | ---: | ---: |
| 1-5 | Easy | 4 | 24 | 600 |
| 5-10 | Difficult | 8 | 45 | 640 |
| 10-15 | Tough | 16 | 34 | 1694 |
| 15-20 | Very Tough | 32 | 57 | 2021 |
| 20-25 | Very Tough | 32 | 37 | 3114 |
| 25-30 | Incredibly Tough | 64 | 51 | 4518 |
| 30-35 | Impossible | 128 | 40 | 11520 |
| 35-40 | Impossible | 128 | 40 | 11520 |
| 40-45 | Impossible | 128 | 40 | 11520 |
| 45-50 | Impossible | 128 | 40 | 11520 |

| Current level | XP to next level | Total XP to reach this level |
| ---: | ---: | ---: |
| 1 | 126 | 0 |
| 2 | 142 | 126 |
| 3 | 157 | 268 |
| 4 | 175 | 425 |
| 5 | 102 | 600 |
| 6 | 115 | 702 |
| 7 | 128 | 817 |
| 8 | 140 | 945 |
| 9 | 155 | 1085 |
| 10 | 271 | 1240 |
| 11 | 304 | 1511 |
| 12 | 338 | 1815 |
| 13 | 372 | 2153 |
| 14 | 409 | 2525 |
| 15 | 323 | 2934 |
| 16 | 363 | 3257 |
| 17 | 404 | 3620 |
| 18 | 444 | 4024 |
| 19 | 487 | 4468 |
| 20 | 498 | 4955 |
| 21 | 560 | 5453 |
| 22 | 622 | 6013 |
| 23 | 685 | 6635 |
| 24 | 749 | 7320 |
| 25 | 722 | 8069 |
| 26 | 813 | 8791 |
| 27 | 903 | 9604 |
| 28 | 993 | 10507 |
| 29 | 1087 | 11500 |
| 30 | 1843 | 12587 |
| 31 | 2073 | 14430 |
| 32 | 2304 | 16503 |
| 33 | 2534 | 18807 |
| 34 | 2766 | 21341 |
| 35 | 1843 | 24107 |
| 36 | 2073 | 25950 |
| 37 | 2304 | 28023 |
| 38 | 2534 | 30327 |
| 39 | 2766 | 32861 |
| 40 | 1843 | 35627 |
| 41 | 2073 | 37470 |
| 42 | 2304 | 39543 |
| 43 | 2534 | 41847 |
| 44 | 2766 | 44381 |
| 45 | 1843 | 47147 |
| 46 | 2073 | 48990 |
| 47 | 2304 | 51063 |
| 48 | 2534 | 53367 |
| 49 | 2766 | 55901 |
| 50 | Beyond this plan | 58667 |

